/* eslint-disable import/no-cycle */
// Organism Indexing
// -------------------------

import { lazy } from 'react';
import AccordionButton from './AccordionButton';
import ProductTabbing from './ProductTabbing';
import AccountDetailInformation from './AccountDetailInformation';
import HeaderDownload from './HeaderDownload';
import AccountDetailHeader from './AccountDetailHeader';
import UtilChangePageGuard from './UtilChangePageGuard';
import PopupAlert from './PopupAlert';
import PopupProgress from './PopupProgress';
import PopupFullScreen from './PopupFullScreen';
import InputMultipleInvoice from './InputMultipleInvoice';
import ProgressStickyWindow from './ProgressStickyWindow';

const Header = lazy(() => import('./Header'));
const PopupFilter = lazy(() => import('./PopupFilter'));
const PopupPdfPreview = lazy(() => import('./PopupPdfPreview'));
const PopupConfirmation = lazy(() => import('./PopupConfirmation'));
const PopupFormatFile = lazy(() => import('./PopupFormatFile'));
const PopupDownload = lazy(() => import('./PopupDownload'));
const PopupUploadProgress = lazy(() => import('./PopupUploadProgress'));
const TransactionHistoryTable = lazy(() => import('./TransactionHistoryTable'));
const TransactionRecordsTable = lazy(() => import('./TransactionRecordsTable'));
const TransactionHistory = lazy(() => import('./TransactionHistory'));
const AccountHoldingList = lazy(() => import('./AccountHoldingList'));
const PopupExitForm = lazy(() => import('./PopupExitForm'));
const AccountDetailTableOmnibus = lazy(() =>
  import('./AccountDetailTableOmnibus')
);
const AccountDetailList = lazy(() => import('./AccountDetailList'));
const AccountDetailTableLoanList = lazy(() =>
  import('./AccountDetailTableLoanList')
);
const AccountDetailTableValasList = lazy(() =>
  import('./AccountDetailTableValasList')
);
const Tabbing = lazy(() => import('./Tabbing'));
const TransactionStatusDetail = lazy(() => import('./TransactionStatusDetail'));
const TransactionStatusForRepair = lazy(() =>
  import('./TransactionStatusForRepair')
);
const TransactionStatusSuccessful = lazy(() =>
  import('./TransactionStatusSuccessful')
);
const TransactionStatusTablePending = lazy(() =>
  import('./TransactionStatusTablePending')
);
const TransactionStatusTableAll = lazy(() =>
  import('./TransactionStatusTableAll')
);
const RequestTransactionTable = lazy(() => import('./RequestTransactionTable'));
const UnderlyingDocumentTable = lazy(() => import('./UnderlyingDocumentTable'));
const FavoriteListTable = lazy(() => import('./FavoriteListTable'));
const RecurringListTable = lazy(() => import('./RecurringListTable'));
const TransactionDetailActionHistory = lazy(() =>
  import('./TransactionDetailActionHistory')
);

const RequestReleaserTable = lazy(() => import('./RequestReleaserTable'));
const PopupInput = lazy(() => import('./PopupInput'));
const RequestConfirmationTable = lazy(() =>
  import('./RequestConfirmationTable')
);
const PopupDownloadTransaction = lazy(() =>
  import('./PopupDownloadTransaction')
);
const TransactionStatusTable = lazy(() => import('./TransactionStatusTable'));
const DsComponentPermutation = lazy(() => import('./DsComponentPermutation'));
const BulkPaymentDetail = lazy(() => import('./BulkPaymentDetail'));
const UploadHistoryTable = lazy(() => import('./UploadHistoryTable'));

const ValidationListingTable = lazy(() => import('./ValidationListingTable'));
const PopupForRepairDuplicate = lazy(() => import('./PopupForRepairDuplicate'));
const TransactionStatusBulkTable = lazy(() =>
  import('./TransactionStatusBulkTable')
);
const PopupForRepairMismatched = lazy(() =>
  import('./PopupForRepairMismatched')
);
const PopupForRepairIncorrectDetail = lazy(() =>
  import('./PopupForRepairIncorrectDetail')
);
const PopupUserGroup = lazy(() => import('./PopupUserGroup'));
const PopupEditFormAccount = lazy(() => import('./PopupEditFormAccount'));
const PopupEditTrxDate = lazy(() => import('./PopupEditTrxDate'));
const PopupSaveFavorite = lazy(() => import('./PopupSaveFavorite'));
const DuplicateItemTable = lazy(() => import('./DuplicateItemTable'));
const PopupFavoriteList = lazy(() => import('./PopupFavoriteList'));
const RecurringDetails = lazy(() => import('./RecurringDetails'));
const PopupRecurringHistory = lazy(() => import('./PopupRecurringHistory'));
const RecurringHistoryPopup = lazy(() => import('./RecurringHistoryPopup')); // copied from PopupRecurringHistory to prevent name redudancy (PopupRecurringHistory on molecules)
const RecurringRecordTable = lazy(() => import('./RecurringRecordTable'));
const UploadArea = lazy(() => import('./UploadArea'));

export {
  AccordionButton,
  Header,
  ProductTabbing,
  TransactionHistoryTable,
  TransactionRecordsTable,
  PopupFilter,
  PopupDownload,
  TransactionHistory,
  AccountHoldingList,
  AccountDetailInformation,
  PopupExitForm,
  PopupPdfPreview,
  PopupUploadProgress,
  HeaderDownload,
  AccountDetailHeader,
  PopupConfirmation,
  AccountDetailTableOmnibus,
  UtilChangePageGuard,
  AccountDetailList,
  AccountDetailTableLoanList,
  AccountDetailTableValasList,
  PopupFormatFile,
  Tabbing,
  TransactionStatusDetail,
  TransactionStatusForRepair,
  TransactionStatusSuccessful,
  PopupAlert,
  TransactionStatusTablePending,
  TransactionStatusTableAll,
  RequestTransactionTable,
  UnderlyingDocumentTable,
  FavoriteListTable,
  RecurringListTable,
  PopupProgress,
  PopupFullScreen,
  RequestReleaserTable,
  TransactionDetailActionHistory,
  PopupInput,
  RequestConfirmationTable,
  PopupDownloadTransaction,
  TransactionStatusTable,
  DsComponentPermutation,
  BulkPaymentDetail,
  UploadHistoryTable,
  ValidationListingTable,
  PopupForRepairDuplicate,
  InputMultipleInvoice,
  TransactionStatusBulkTable,
  PopupForRepairMismatched,
  PopupForRepairIncorrectDetail,
  PopupUserGroup,
  PopupEditFormAccount,
  PopupEditTrxDate,
  PopupSaveFavorite,
  ProgressStickyWindow,
  DuplicateItemTable,
  PopupFavoriteList,
  RecurringDetails,
  PopupRecurringHistory,
  RecurringHistoryPopup,
  RecurringRecordTable,
  UploadArea
};
