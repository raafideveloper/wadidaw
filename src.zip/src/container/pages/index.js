// Pages Indexing
// -------------------------

import { lazy } from 'react';

const DesignSystem = lazy(() => import('./DesignSystem'));
const Home = lazy(() => import('./Home'));
const DashboardHome = lazy(() => import('./DashboardHome'));
const HelveticaDisplay = lazy(() => import('./HelveticaDisplay'));
const CasaHolding = lazy(() => import('./CasaHolding'));
const CasaDetail = lazy(() => import('./CasaDetail'));
const ValasDetail = lazy(() => import('./ValasDetail'));
const ValasList = lazy(() => import('./ValasList'));
const TimeDepositHolding = lazy(() => import('./TimeDepositHolding'));
const TimeDepositDetail = lazy(() => import('./TimeDepositDetail'));
const Services = lazy(() => import('./Services'));
const LocalCurrencyTransfer = lazy(() => import('./LocalCurrencyTransfer'));
const LoanHolding = lazy(() => import('./LoanHolding'));
const LoanDetails = lazy(() => import('./LoanDetails'));
const Omnibus = lazy(() => import('./Omnibus'));
const ListLoan = lazy(() => import('./ListLoan'));
const TransactionStatusPending = lazy(() =>
  import('./TransactionStatusPending')
);
const TransactionStatusForRepair = lazy(() =>
  import('./TransactionStatusForRepair')
);
const TransactionStatusSuccess = lazy(() =>
  import('./TransactionStatusSuccess')
);
const TransactionStatusUnsuccess = lazy(() =>
  import('./TransactionStatusUnsuccess')
);
// const TransactionStatusBillingPLN = lazy(() =>
//   import('./TransactionStatusDetailBillingPLN')
// );
const Request = lazy(() => import('./Request'));
const RequestForRepair = lazy(() => import('./RequestForRepair'));
const TransactionStatusAll = lazy(() => import('./TransactionStatusAll'));
const TransactionStatusForwardDated = lazy(() =>
  import('./TransactionStatusForwardDated')
);
const RequestReleaser = lazy(() => import('./RequestReleaser'));
const RequestForApproval = lazy(() => import('./RequestForApproval'));
const RequestForVerify = lazy(() => import('./RequestForVerify'));
const RequestForVerifyConfirmation = lazy(() =>
  import('./RequestForVerifyConfirmation')
);
const RequestForApprovalConfirmation = lazy(() =>
  import('./RequestForApprovalConfirmation')
);
const TransactionStatusDetailTransaction = lazy(() =>
  import('./TransactionStatusDetailTransaction')
);
const RequestForApprovalDetail = lazy(() =>
  import('./RequestForApprovalDetail')
);
const RequestForRepairDetail = lazy(() => import('./RequestForRepairDetail'));
const TransactionStatusDetailTransactionSuccessful = lazy(() =>
  import('./TransactionStatusSuccessfulDetail')
);
const RequestForRepairSuccess = lazy(() => import('./RequestForRepairSuccess'));
const RequestForRepairDetailEdit = lazy(() =>
  import('./RequestForRepairDetailEdit')
);
const RequestReleaserDetail = lazy(() => import('./RequestReleaserDetail'));
const TransactionStatusUnsuccessfulDetail = lazy(() =>
  import('./TransactionStatusUnsuccessfulDetail')
);
const TransactionStatusForRepairDetail = lazy(() =>
  import('./TransactionStatusForRepairDetail')
);
const RequestReleaserConfirmation = lazy(() =>
  import('./RequestReleaserConfirmation')
);
const TopUp = lazy(() => import('./TopUp'));
const RequestForRepairAll = lazy(() => import('./RequestForRepairAll'));
const BillPayment = lazy(() => import('./BillPayment'));
const RequestAllForApproval = lazy(() => import('./RequestAllForApproval'));
const RequestAllForRepair = lazy(() => import('./RequestAllForRepair'));
const RequestAllForReleaser = lazy(() => import('./RequestAllForReleaser'));
const RequestAllForVerify = lazy(() => import('./RequestAllForVerify'));
const TransactionStatusForwardDatedDetail = lazy(() =>
  import('./TransactionStatusForwardDatedDetail')
);
const TransactionStatusDetailTopup = lazy(() =>
  import('./TransactionStatusDetailTopup')
);
const TransactionStatusDetailBilling = lazy(() =>
  import('./TransactionStatusDetailBilling')
);
const RequestForRejectConfirmation = lazy(() =>
  import('./RequestForRejectConfirmation')
);
const RequestForVerifyDetail = lazy(() => import('./RequestForVerifyDetail'));
const TransactionStatusDetail = lazy(() => import('./TransactionStatusDetail'));
const RequestForApprovalSendForRepairConfirmation = lazy(() =>
  import('./RequestForApprovalSendForRepairConfirmation')
);
const ChequeBook = lazy(() => import('./ChequeBook'));
const BulkPaymentRecordDetail = lazy(() => import('./BulkPaymentRecordDetail'));
const BulkPayment = lazy(() => import('./BulkPayment'));
const BulkPaymentUploadForm = lazy(() => import('./BulkPaymentUploadForm'));
const BulkPaymentDetailPage = lazy(() => import('./BulkPaymentDetailPage'));
// const BulkPaymentDetail = lazy(() => import('./BulkPaymentDetail'));
const ForeignCurrencyTransfer = lazy(() => import('./ForeignCurrencyTransfer'));
const TransactionStatusDetailBulk = lazy(() =>
  import('./TransactionStatusDetailBulk')
);
const RecurringPage = lazy(() => import('./Recurring'));
const RecurringForm = lazy(() => import('./RecurringForm'));
const RecurringDetail = lazy(() => import('./RecurringDetail'));
const FavoritesPage = lazy(() => import('./Favorites'));
const TransactionStatusDetailChequeBook = lazy(() =>
  import('./TransactionStatusDetailChequeBook')
);
const TransactionStatusDetailForeignCurrencyTransfer = lazy(() =>
  import('./TransactionStatusDetailForeignCurrencyTransfer')
);

const TransactionStatusDetailFavorite = lazy(() =>
  import('./TransactionStatusDetailFavorite')
);
const FavoritesForm = lazy(() => import('./FavoritesForm'));
const NewLogin = lazy(() => import('./NewLogin'));
const Logout = lazy(() => import('./Logout'));

export {
  DesignSystem,
  Home,
  DashboardHome,
  HelveticaDisplay,
  CasaHolding,
  CasaDetail,
  ValasDetail,
  ValasList,
  TimeDepositHolding,
  TimeDepositDetail,
  Services,
  LocalCurrencyTransfer,
  LoanHolding,
  LoanDetails,
  Omnibus,
  ListLoan,
  TransactionStatusPending,
  TransactionStatusForRepair,
  TransactionStatusSuccess,
  TransactionStatusUnsuccess,
  Request,
  RequestForRepair,
  TransactionStatusAll,
  TransactionStatusForwardDated,
  RequestReleaser,
  RequestForApproval,
  RequestForApprovalConfirmation,
  TransactionStatusDetailTransaction,
  RequestForApprovalDetail,
  RequestForRepairDetail,
  TransactionStatusDetailTransactionSuccessful,
  RequestForRepairSuccess,
  RequestForRepairDetailEdit,
  RequestReleaserDetail,
  TransactionStatusUnsuccessfulDetail,
  TransactionStatusForRepairDetail,
  RequestReleaserConfirmation,
  TopUp,
  RequestForRepairAll,
  BillPayment,
  RequestAllForApproval,
  RequestAllForRepair,
  RequestAllForReleaser,
  RequestAllForVerify,
  TransactionStatusForwardDatedDetail,
  TransactionStatusDetailTopup,
  TransactionStatusDetailBilling,
  RequestForRejectConfirmation,
  RequestForVerify,
  RequestForVerifyDetail,
  TransactionStatusDetail,
  RequestForApprovalSendForRepairConfirmation,
  ChequeBook,
  RequestForVerifyConfirmation,
  BulkPaymentRecordDetail,
  BulkPayment,
  BulkPaymentDetailPage,
  // BulkPaymentDetail,
  ForeignCurrencyTransfer,
  TransactionStatusDetailBulk,
  RecurringPage,
  RecurringForm,
  RecurringDetail,
  FavoritesPage,
  TransactionStatusDetailChequeBook,
  FavoritesForm,
  TransactionStatusDetailForeignCurrencyTransfer,
  TransactionStatusDetailFavorite,
  NewLogin,
  Logout,
  BulkPaymentUploadForm
};
