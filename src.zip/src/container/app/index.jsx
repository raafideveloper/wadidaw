/* eslint-disable prettier/prettier */
import React, { Suspense } from 'react';
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect
} from 'react-router-dom';

import { Preloader } from 'components';

import AppRoutes from 'config/routes/';
import { MainTemplate } from 'container/templates';

function App() {
  return (
    <Router>
      <MainTemplate>
        <Suspense fallback={<Preloader type="modal" show enableScroll />}>
          <Switch>
            {AppRoutes.map((route) => (
              <Route key={route.id} {...route} />
            ))}
            {/* <Redirect from='/dashboard' to='/dashboard/home' /> */}
            <Redirect from='/design-system' to='/design-system/introduction' />
            <Redirect from='*' to='/error-404' />
          </Switch>
        </Suspense>
      </MainTemplate>
    </Router>
  );
}

export default App;
