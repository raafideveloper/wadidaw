// Templates Indexing
// -------------------------

import ClassicDashboard from './ClassicDashboard';
import AccountHolding from './AccountHolding';
import AccountDetail from './AccountDetail';
import TransactionForm from './TransactionForm';
import MainTemplate from './MainTemplate';
import AccountList from './AccountList';
import TransactionStatus from './TransactionStatus';

import TransactionStatusDetail from './TransactionStatusDetail';

import RequestMultiRole from './RequestMultiRole';
export {
  ClassicDashboard,
  AccountHolding,
  AccountDetail,
  TransactionForm,
  MainTemplate,
  AccountList,
  TransactionStatus,
  TransactionStatusDetail
,RequestMultiRole };
