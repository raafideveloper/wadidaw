import { useState, useEffect } from 'react';

function getData(initialData) {
  // const arr = []
  const [data, setData] = useState(initialData);
  // async function gets() {
  //   fetch(url
  //     , {
  //       headers: {
  //         'Content-Type': 'application/json',
  //         'Accept': 'application/json'
  //       }
  //     }
  //   )
  //     .then(await function (response) {
  //       return response.json()
  //     })
  //     .then(await function (myJson) {
  //       setData(myJson)
  //     })
  // }

  useEffect(() => {
    // gets()
    setData(data);
  }, []);

  return data;
}

export default getData;
