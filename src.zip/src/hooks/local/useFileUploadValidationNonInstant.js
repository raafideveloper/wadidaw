/* eslint-disable prefer-const */
/* eslint-disable no-case-declarations */
import { useEffect, useState } from 'react';
import accountDetailData from 'assets/dummy-data/validating-listing-data-non-instant.json';
import { multiLanguage } from 'helpers/ConfigLanguage';
import useQuery from './useQuery';

const useFileUploadValidationNonInstant = () => {
  const [dataNonInstant, setDataNonInstant] = useState(accountDetailData);
  const [flow, setFlow] = useState('');
  const totalData = accountDetailData.length;
  const [index, setIndex] = useState(0);
  const query = useQuery();
  const [queryVars] = useState({
    flow: query.get('flow')
  });
  let sto = null;

  const repairObj = {
    validationStatusCode: '2',
    validationStatus: multiLanguage.NeedToRepair,
    isChecked: false,
    record: '10',
    pass: '7',
    toRepair: '3',
    to:
      '/services/bulk-payment/detail?error_type=to-repair&flow=repair&file_type=multiple-account&approval_type=per-file',
    paymentType: 'Bill Payment & Top Up',
    fileName: 'Top Up Gopay',
    totalAmount: '700000',
    uploadDate: 1624241520000,
    fileNumber: ''
  };

  useEffect(() => {
    console.log('queryVars.flow', queryVars.flow);
    let tempData = dataNonInstant;
    switch (queryVars.flow) {
      case 'validation-all':
        setFlow('validation-all');
        tempData[index].validationStatusCode = '0';
        tempData[index].validationStatus = multiLanguage.Validating;
        tempData[index].isChecked = false;
        setDataNonInstant([...tempData]);

        if (index < totalData - 1) setIndex(index + 1);
        break;
      case 'ready-proceed':
        setFlow('ready-proceed');
        // const tempData = data;
        tempData[index].validationStatusCode = '1';
        tempData[index].validationStatus = multiLanguage.ReadyToProceed;
        tempData[index].isChecked = true;
        setDataNonInstant([...tempData]);

        if (index < totalData - 1) setIndex(index + 1);
        break;
      case 'repair':
        setFlow('repair');
        sto = setTimeout(() => {
          if (index <= totalData - 1) {
            // const tempData = data;

            if (index === 0) {
              tempData[index] = {
                ...tempData[index],
                ...repairObj
              };

              setDataNonInstant([...tempData]);
            } else {
              tempData[index].validationStatusCode = '1';
              tempData[index].validationStatus = multiLanguage.ReadyToProceed;
              tempData[index].isChecked = true;
              setDataNonInstant([...tempData]);
            }

            if (index < totalData - 1) setIndex(index + 1);
          }
        }, 1500);
        break;
      default:
        setFlow('normal');
        sto = setTimeout(() => {
          if (index <= totalData - 1) {
            // const tempData = data;
            tempData[index].validationStatusCode = '1';
            tempData[index].validationStatus = multiLanguage.ReadyToProceed;
            tempData[index].isChecked = true;
            setDataNonInstant([...tempData]);

            if (index < totalData - 1) setIndex(index + 1);
          }
        }, 1500);
        break;
    }
    return () => clearTimeout(sto);
  }, [index, queryVars.flow]);

  return [dataNonInstant, flow];
};

export default useFileUploadValidationNonInstant;
