import { useState, useEffect, useCallback } from 'react';
import { stringSort, updateDataPaging } from 'helpers';

const initialState = {
  serverSide: false,
  currentPage: 1,
  dataPerPage: 10,
  activeSort: '',
  sortDes: false // default is ascending,
};

function usePagination(initialData, defaultConfig = initialState) {
  // states
  const [state, setState] = useState({ ...initialState, ...defaultConfig });
  const [datas, setDatas] = useState([]);
  // variables
  const totalData = initialData.length;
  const totalPage = Math.ceil(totalData / state.dataPerPage);
  const dataSorted = stringSort(initialData, state.activeSort, state.sortDesc);

  // combines
  const [dataPaged, setDataPaged] = useState(
    updateDataPaging(dataSorted, state.dataPerPage)
  );

  // handler
  const handleSetDataPaged = useCallback(
    (arr) => {
      setDataPaged(updateDataPaging(arr, state.dataPerPage));
    },
    [state.dataPerPage]
  );

  // getters
  const getPagedItems = (arr, current) => {
    return arr.filter((val) => val.page === current);
  };

  // for handle next page / data
  const handleNext = () => {
    if (state.currentPage < totalPage) {
      setState((v) => ({
        ...v,
        currentPage: v.currentPage + 1
      }));
    }
  };

  // for handle prev page / data
  const handlePrev = () => {
    if (state.currentPage > 1) {
      if (!state.serverSide) {
        setState((v) => ({
          ...v,
          currentPage: v.currentPage - 1
        }));
      }

      return state.currentPage;
    }
    return 1;
  };

  const handleStart = () => {
    if (state.currentPage > 1) {
      if (!state.serverSide) {
        setState((v) => ({
          ...v,
          currentPage: 1
        }));
      }

      return 1;
    }
    return state.currentPage;
  };

  const handleLast = () => {
    if (state.currentPage < totalPage) {
      if (!state.serverSide) {
        setState((v) => ({
          ...v,
          currentPage: totalPage
        }));
      }

      return totalPage;
    }

    return state.currentPage;
  };

  const handleResetState = useCallback(() => {
    setState({
      ...initialState,
      ...defaultConfig
    });
  }, [defaultConfig]);

  const getPageFirstIndex = () => {
    if (state.currentPage === 1) {
      return state.currentPage;
    }
    return state.dataPerPage * state.currentPage - (state.dataPerPage - 1);
  };

  const getPageLastIndex = () => {
    if (state.currentPage === 1) {
      return state.dataPerPage;
    }

    if (state.currentPage >= totalPage) {
      return totalData;
    }

    return state.dataPerPage * state.currentPage;
  };

  useEffect(() => {
    if (initialData) {
      setDatas(initialData);
    }
  }, [initialData]);

  // init / re-init when has changes datas prop
  useEffect(() => {
    if (datas) {
      handleSetDataPaged(datas);
    }
  }, [datas, handleSetDataPaged]);

  return {
    setPagination: setState,
    setItems: handleSetDataPaged,
    nextPage: handleNext,
    prevPage: handlePrev,
    startPage: handleStart,
    reset: handleResetState,
    lastPage: handleLast,
    items: getPagedItems(dataPaged, state.currentPage),
    allItems: dataPaged,
    state: {
      ...state,
      totalPage,
      totalData,
      firstIndex: getPageFirstIndex(),
      lastIndex: getPageLastIndex()
    }
  };
}

export default usePagination;
