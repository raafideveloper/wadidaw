import { useState, useEffect, useCallback } from 'react';

let uploadDocsTempFiles = []; // Workaround karena update state tidak disupport dengan baik oleh onProgress callback

const useFileUpload = () => {
  const [fileUploadState, setFileUploadState] = useState([]);
  const [allFilesDone, setAllFilesDone] = useState(false);
  const [totalUpload, setTotalUpload] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [isShowPopupError, setIsShowPopupError] = useState(true);
  // const newFile = [];

  const handleUploadChange = useCallback((fileList) => {
    console.log('newFile handleChange handleUploadChange++++++++', fileList);

    // fileList.forEach((item, i) => {
    //   newFile.push(item);
    // });

    // if (fileUploadState.length > 0 && fileUploadState.length < newFile.length) {
    //   newFile.splice(0, fileUploadState.length);
    // }

    setFileUploadState(fileList);
    uploadDocsTempFiles = fileList;

    // Setiap kali uplaod file baru, maka set allfilesdone = false
    // kemudian set juga totalUpload jadi 0 (total upload ini akan menentukan apakah bakal pindah halaman upload list atau tidak, maka setiap kali file ditambah, harus dibikin 0 agar tidak berpindah tempat dulu)
    setAllFilesDone(false);
    setIsUploading(true);
  });

  const handleUploadError = useCallback((reason, file) => {
    console.log('newFile uploadError', { file, reason });
  });

  const removeSpesificFile = (index) => {
    const classNames = document.getElementsByClassName(
      'rs-uploader-file-item-btn-remove rs-btn-close'
    );
    console.log(classNames, 'deletedClassName', index);
    if (classNames[index] && classNames[index].click) {
      classNames[index].click();
    }
  };

  const handleRemoveFile = useCallback((deletedFile, index) => {
    console.log('newFile handleChange Deleted=====', deletedFile, index);
    removeSpesificFile(index);
    const files = uploadDocsTempFiles;
    const fileIndex = files.findIndex(
      (item) => item.fileKey === deletedFile.fileKey
    );

    files.splice([fileIndex], 1);

    setFileUploadState([...files]);
    uploadDocsTempFiles = [...files];
  });

  const handleUploadProgress = useCallback((percent, file) => {
    if (uploadDocsTempFiles.length > 0) {
      // eslint-disable-next-line prefer-const
      let temp = [];
      uploadDocsTempFiles.forEach((item) => {
        if (item.fileKey === file.fileKey) {
          temp.push({
            blobFile: item.blobFile,
            fileKey: item.fileKey,
            name: item.name,
            progress: percent,
            status: file.status
          });
        } else {
          temp.push(item);
        }
      });

      uploadDocsTempFiles = temp;
      setFileUploadState(uploadDocsTempFiles);
    }
  });

  useEffect(() => {
    let done = false;
    console.log('fileUploadState');
    for (let i = 0; i < fileUploadState.length; i++) {
      if (!fileUploadState[i].progress || fileUploadState[i].progress < 100) {
        done = false;
        break;
      } else {
        done = true;
      }
    }

    if (done === true) {
      setTimeout(() => {
        setAllFilesDone(true);
      }, 2000);
    }

    if (isShowPopupError) {
      setTimeout(() => {
        setAllFilesDone(false); // set all files done if error showing
      }, 2000);
    }

    setTotalUpload(fileUploadState.length);
    if (fileUploadState.length < 1) setIsUploading(false);
  }, [fileUploadState, isShowPopupError]);

  useEffect(() => {
    uploadDocsTempFiles = [];
  }, []);

  return {
    fileUploadState,
    isUploading,
    handleUploadChange,
    handleUploadError,
    handleUploadProgress,
    handleRemoveFile,
    removeSpesificFile,
    allFilesDone,
    totalUpload,
    setFileUploadState,
    setIsShowPopupError
  };
};

export default useFileUpload;
