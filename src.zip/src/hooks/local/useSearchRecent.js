import { useState, useCallback, useEffect } from 'react';
import dropdownData from 'assets/dummy-data/dropdown-search-value.json';

// HOOKS INI DIGUNAKAN HANYA UNTUK SIMULASI SEARCH SAJA
// NANTI TUGAS HOOKS INI HARUS DIREPLACE OLEH "INTEGRASI" KE API
const useSearchRecent = (listData) => {
  const listDropdown = listData !== undefined ? listData : dropdownData;
  const maximumDataDisplay = 10;
  const [data, setData] = useState([]);
  const [firstLoadData, setFirstLoadData] = useState(
    listDropdown.slice(0, maximumDataDisplay)
  );
  const [currentPage, setCurrentPage] = useState(1);
  const [dataReady, setDataReady] = useState(false);

  /* Function pencarian dan highlight */
  const searchData = useCallback((keyword) => {
    setDataReady(false);
    setData([]); // ini dipasang agar datanya kosong, sehingga ReactPlaceholder or Loader yg letaknya dibawah terlihat

    const sto = setTimeout(() => {
      let newData = [...data];

      newData = listDropdown.filter((val) => {
        return (
          val.text.toLowerCase().includes(keyword) ||
          val.text.toLowerCase().includes(
            keyword
              .replace(/(\d)-/g, '$1')
              .replace(/-(\d)/g, '$1')
              .replace(/(\d)-(\d)-/g, '$1$2')
              .replace(/(\d)-(\d)/g, '$1$2')
          )
        );
      });

      setData(newData);
      setDataReady(true);
    }, 1000); // anggap saja call API perlu waktu 1 detik

    return () => clearTimeout(sto);
  });

  /* Mendapatkan semua data */
  const getAllData = useCallback(() => {
    setData(listDropdown);
  });

  /* Mendapatkan data lagi berdasarkan pagination */
  const getMoreData = useCallback(() => {
    const totalPage = Math.ceil(listDropdown.length / maximumDataDisplay);
    if (currentPage < totalPage) setCurrentPage((old) => old + 1);
  });

  const setDefaultData = useCallback(() => {
    // ini dipanggil saat keyword < minimumKeyword atau set ke default data tanpa loading
    setData(firstLoadData);
    setCurrentPage(1);
  });

  const clearRecentData = () => {
    setFirstLoadData([]);
    setData([]);
  };

  useEffect(() => {
    setDataReady(false);
    const sto = setTimeout(() => {
      const newData = listDropdown.slice(0, currentPage * maximumDataDisplay);
      setData(newData);
      if (currentPage === 1) setFirstLoadData(newData);
      setDataReady(true);
    }, 2000);

    return () => clearTimeout(sto);
  }, [currentPage]);

  return {
    data,
    firstLoadData,
    dataReady,
    searchData,
    getAllData,
    getMoreData,
    setDefaultData,
    clearRecentData
  };
};

export default useSearchRecent;
