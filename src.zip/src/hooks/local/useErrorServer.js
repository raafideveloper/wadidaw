import { useState, useCallback } from 'react';

const useErrorServer = () => {
  const errorList = [
    {
      errorCode: '500',
      errorTitle: 'ThisRequestHasTimeOut',
      errorDesc: 'PleaseTryToRefreshThisPageOrCCloseToViewOtherPage'
    },
    {
      errorCode: '504',
      errorTitle: 'Nointernetconnection',
      errorDesc: 'Checkyourinternetconnectionandtrytorefreshthispage'
    }
  ];
  const [showPopup, setShowPopup] = useState(false);
  const [codeError, setcodeError] = useState('');
  const [errTitle, setErrTitle] = useState('');
  const [errDesc, setErrDesc] = useState('');

  const handleStatusError = useCallback((errorServerType, codeErr) => {
    switch (errorServerType) {
      case 'request-time-out':
        setTimeout(() => {
          setShowPopup(true);
          const dataError = errorList.filter(
            (data) => data.errorCode === codeErr
          );
          setcodeError(dataError[0].errorCode);
          setErrTitle(dataError[0].errorTitle);
          setErrDesc(dataError[0].errorDesc);
        }, 1000);
        break;
      case 'no-internet-connection':
        setTimeout(() => {
          setShowPopup(true);
          const dataError = errorList.filter(
            (data) => data.errorCode === codeErr
          );
          setcodeError(dataError[0].errorCode);
          setErrTitle(dataError[0].errorTitle);
          setErrDesc(dataError[0].errorDesc);
        }, 1000);
        break;

      default:
        setShowPopup(false);
        break;
    }
  });

  const handleBtnPrimary = (val, codeErr) => {
    // console.log({ val, codeErr });
    setShowPopup(val);
  };

  const handleBtnSecondary = (val, codeErr) => {
    // console.log({ val, codeErr });
    setShowPopup(val);
  };

  return {
    showPopup,
    codeError,
    errTitle,
    errDesc,
    handleStatusError,
    handleBtnPrimary,
    handleBtnSecondary
  };
};

export default useErrorServer;
