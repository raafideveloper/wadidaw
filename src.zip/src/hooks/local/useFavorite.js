import { useState, useEffect } from 'react';
import { delay, removeAllHyphen } from 'helpers';
import useSearchRecent from './useSearchRecent';
import usePagination from './usePagination';
import useQuery from './useQuery';

const initialState = {
  serverSide: false
};

function useFavorite(
  favoriteData,
  recentData,
  fecthAPI = () => {},
  defaultConfig = initialState
) {
  // console.log(favoriteData, recentData);
  // high order / custom hooks

  const query = useQuery();

  const {
    data,
    dataReady,
    getMoreData,
    searchData,
    setDefaultData
  } = useSearchRecent(recentData);

  // state hooks
  const [state] = useState(defaultConfig);
  const [active, setActive] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [recentOptions, setRecentOptions] = useState([]);
  const [favoriteItems, setFavoriteItems] = useState([]);
  const [queryVars] = useState({
    statestatus: query.get('statestatus')
  });

  const pagination = usePagination(favoriteItems, {
    dataPerPage: 10,
    activeSort: 'favoriteTitle',
    serverSide: state.serverSide
  });

  const isSearch = Boolean(searchValue) && searchValue.length >= 3;

  // for simulate empty state;
  const forceEmpty = queryVars.statestatus === 'empty';
  const isEmptyState =
    (favoriteItems.length <= 0 && !loading && !isSearch) || forceEmpty;
  const isEmptySearch = favoriteItems.length <= 0 && !loading && isSearch;

  console.log('isEmptyState', isEmptyState, isEmptySearch);

  const handleSearch = (value, min) => {
    console.log('trigger handleSearch');
    if (min) {
      return setDefaultData();
    }
    return searchData(value);
  };

  const handlePressEnterSearch = (value) => {
    console.log('trigger handlePressEnterSearch');
    setSearchValue(value);
  };

  const handleClickItemRecentSearch = (value) => {
    console.log('trigger handleClickItemRecentSearch', 'value', value);
    if (value.text) {
      setSearchValue(value.text);
    }
  };

  const handleClickSelectedRecentSearch = () => {
    console.log('trigger handleClickSelected');
  };

  const handleClearRecentSearch = () => {
    console.log('trigger handleClearRecentSearch');
  };

  const handleRemoveSearch = () => {
    console.log('trigger handleRemoveSearch');
    setRecentOptions(recentData);
    setSearchValue('');
  };

  const handleRemoveListRecentSearch = () => {
    console.log('trigger handleRemoveListRecentSearch');
  };

  const handlePressIconSearch = (isCanSearch, val) => {
    console.log(
      'trigger handlePressIconSearch',
      'isCanSearch',
      isCanSearch,
      'val',
      val
    );
    return setSearchValue(val);
  };

  const handleScrollEndRecentSearch = () => {
    console.log('trigger handleScrollEndRecentSearch');
    getMoreData();
  };

  const init = () => {
    setActive(true);
  };

  const resetState = () => {
    setSearchValue('');
    setRecentOptions([]);
    setFavoriteItems([]);
    setActive(false);
  };

  useEffect(() => {
    setRecentOptions(data);
  }, [data]);

  const recentSearchProps = {
    options: recentOptions,
    onClickSelected: handleClickSelectedRecentSearch,
    onClickItem: handleClickItemRecentSearch,
    onSearch: handleSearch,
    onClickClear: handleClearRecentSearch,
    onClickRemove: handleRemoveSearch,
    onClickRemoveList: handleRemoveListRecentSearch,
    handlePressEnter: handlePressEnterSearch,
    onClickSearch: handlePressIconSearch,
    readySearch: dataReady,
    searchMethod: 'api',
    onScrollEnd: handleScrollEndRecentSearch
  };

  // useEffects
  useEffect(() => {
    if (active && favoriteData && favoriteData.length > 0) {
      if (state.serverSide) {
        setLoading(true);
        //  fetch api here
        if (
          searchValue &&
          typeof searchValue === 'string' &&
          searchValue.length >= 3
        ) {
          //  fetch api here
          fecthAPI({ searchValue });
        } else {
          //  fetch api here
          fecthAPI();
        }
      } else if (
        searchValue &&
        typeof searchValue === 'string' &&
        searchValue.length >= 3
      ) {
        setLoading(true);
        delay(1000).then(() => {
          const newItems = favoriteData.filter((item) => {
            const name = item.favoriteTitle;
            const number = item.favoriteDetails[0].noteValue;

            console.log(
              'name',
              name,
              searchValue.toLowerCase(),
              removeAllHyphen(searchValue.toLowerCase())
            );
            console.log(
              'number',
              number,
              searchValue.toLowerCase(),
              removeAllHyphen(searchValue.toLowerCase())
            );

            if (
              name &&
              (name.toLowerCase().includes(searchValue.toLowerCase()) ||
                name
                  .toLowerCase()
                  .includes(removeAllHyphen(searchValue.toLowerCase())))
            ) {
              return true;
            }

            if (
              number &&
              (number.includes(searchValue.toLowerCase()) ||
                number.includes(removeAllHyphen(searchValue.toLowerCase())))
            ) {
              return true;
            }

            return false;
          });
          setFavoriteItems(newItems);
          setLoading(false);
        });
      } else {
        setLoading(true);
        delay(1000).then(() => {
          setFavoriteItems(favoriteData);
          setLoading(false);
        });
      }
    }
  }, [active, favoriteData, searchValue, state.serverSide]);

  useEffect(() => {
    if (isSearch) {
      pagination.startPage();
    }
  }, [isSearch]);

  return {
    init,
    searchValue,
    loading,
    isSearch,
    setLoading,
    resetState,
    isEmptyState,
    isEmptySearch,
    favoriteItems,
    items: pagination.items,
    recentSearchProps,
    pagination
  };
}

export default useFavorite;
