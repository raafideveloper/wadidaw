/* eslint-disable prefer-const */
/* eslint-disable no-case-declarations */
import { useEffect, useState } from 'react';
import accountDetailData from 'assets/dummy-data/validating-listing-data.json';
import { multiLanguage } from 'helpers/ConfigLanguage';
import useQuery from './useQuery';

const useFileUploadValidation = () => {
  const [data, setData] = useState(accountDetailData);
  const [flow, setFlow] = useState('');
  const totalData = accountDetailData.length;
  const [index, setIndex] = useState(0);
  const query = useQuery();
  const [queryVars] = useState({
    flow: query.get('flow')
  });
  let sto = null;

  useEffect(() => {
    console.log('queryVars.flow', queryVars.flow);
    let tempData = data;
    switch (queryVars.flow) {
      case 'validation-all':
        setFlow('validation-all');
        tempData[index].validationStatusCode = '0';
        tempData[index].validationStatus = multiLanguage.Validating;
        tempData[index].isChecked = false;
        setData([...tempData]);

        if (index < totalData - 1) setIndex(index + 1);
        break;
      case 'ready-proceed':
        setFlow('ready-proceed');
        // const tempData = data;
        tempData[index].validationStatusCode = '1';
        tempData[index].validationStatus = multiLanguage.ReadyToProceed;
        tempData[index].isChecked = true;
        setData([...tempData]);

        if (index < totalData - 1) setIndex(index + 1);
        break;
      case 'repair':
        setFlow('repair');
        sto = setTimeout(() => {
          if (index <= totalData - 1) {
            // const tempData = data;

            if (index === 4) {
              tempData[index].validationStatusCode = '2';
              tempData[index].validationStatus = multiLanguage.NeedToRepair;
              tempData[index].isChecked = false;
              tempData[index].record = '5';
              tempData[index].pass = '2';
              tempData[index].toRepair = '3';
              tempData[index].to =
                '/services/bulk-payment/detail?error_type=with-error-fully';
              setData([...tempData]);
            } else {
              tempData[index].validationStatusCode = '1';
              tempData[index].validationStatus = multiLanguage.ReadyToProceed;
              tempData[index].isChecked = true;
              setData([...tempData]);
            }

            if (index < totalData - 1) setIndex(index + 1);
          }
        }, 1500);
        break;
      default:
        setFlow('normal');
        sto = setTimeout(() => {
          if (index <= totalData - 1) {
            // const tempData = data;
            tempData[index].validationStatusCode = '1';
            tempData[index].validationStatus = multiLanguage.ReadyToProceed;
            tempData[index].isChecked = true;
            setData([...tempData]);

            if (index < totalData - 1) setIndex(index + 1);
          }
        }, 1500);
        break;
    }
    return () => clearTimeout(sto);
  }, [index, queryVars.type]);

  return [data, flow];
};

export default useFileUploadValidation;
