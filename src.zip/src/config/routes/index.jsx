import {
  Home,
  DesignSystem,
  DashboardHome,
  HelveticaDisplay,
  CasaHolding,
  CasaDetail,
  ValasDetail,
  ValasList,
  TimeDepositHolding,
  TimeDepositDetail,
  Services,
  LocalCurrencyTransfer,
  LoanHolding,
  LoanDetails,
  Omnibus,
  ListLoan,
  // TransactionStatusPending,
  // TransactionStatusForRepair,
  // TransactionStatusSuccess,
  // TransactionStatusUnsuccess,
  // TransactionStatusAll,
  // TransactionStatusForwardDated,
  RequestForApprovalConfirmation,
  TransactionStatusDetailTransaction,
  RequestForApprovalDetail,
  RequestForRepairDetail,
  TransactionStatusDetailTransactionSuccessful,
  RequestForRepairSuccess,
  RequestForRepairDetailEdit,
  RequestReleaserDetail,
  TransactionStatusUnsuccessfulDetail,
  TransactionStatusForRepairDetail,
  RequestReleaserConfirmation,
  TopUp,
  BillPayment,
  RequestAllForApproval,
  RequestAllForRepair,
  RequestAllForReleaser,
  RequestAllForVerify,
  TransactionStatusForwardDatedDetail,
  TransactionStatusDetailTopup,
  TransactionStatusDetailBilling,
  RequestForRejectConfirmation,
  RequestForVerifyDetail,
  TransactionStatusDetail,
  RequestForApprovalSendForRepairConfirmation,
  // RequestForVerify,
  ChequeBook,
  RequestForVerifyConfirmation,
  BulkPaymentRecordDetail,
  BulkPayment,
  BulkPaymentUploadForm,
  BulkPaymentDetailPage,
  ForeignCurrencyTransfer,
  TransactionStatusDetailBulk,
  RecurringPage,
  RecurringForm,
  RecurringDetail,
  FavoritesPage,
  Request,
  TransactionStatusDetailChequeBook,
  FavoritesForm,
  TransactionStatusDetailForeignCurrencyTransfer,
  TransactionStatusDetailFavorite,
  NewLogin,
  Logout
} from 'container/pages';

const AppRoutes = [
  {
    id: 0,
    path: '/login',
    component: Home,
    exact: true
  },
  {
    id: 1,
    path: '/',
    component: DashboardHome,
    exact: true
  },
  {
    id: 2,
    path: '/design-system/introduction',
    component: DesignSystem,
    exact: true
  },
  {
    id: 3,
    path: '/design-system/content',
    component: DesignSystem,
    exact: true
  },
  {
    id: 4,
    path: '/design-system/layout',
    component: DesignSystem,
    exact: true
  },
  {
    id: 5,
    path: '/design-system/basic-visual',
    component: DesignSystem,
    exact: true
  },
  {
    id: 6,
    path: '/design-system/components',
    component: DesignSystem,
    exact: true
  },
  {
    id: 7,
    path: '/design-system/template',
    component: DesignSystem,
    exact: true
  },
  // {
  //   id: 6,
  //   path: '/design-system/atoms',
  //   component: DesignSystem,
  //   exact: true
  // },
  // {
  //   id: 7,
  //   path: '/design-system/molecules',
  //   component: DesignSystem,
  //   exact: true
  // },
  // {
  //   id: 8,
  //   path: '/design-system/organisms',
  //   component: DesignSystem,
  //   exact: true
  // },

  {
    id: 9,
    path: '/design-system/colors',
    component: DesignSystem,
    exact: true
  },
  {
    id: 10,
    path: '/design-system/iconography',
    component: DesignSystem,
    exact: true
  },
  {
    id: 11,
    path: '/design-system/avatar',
    component: DesignSystem,
    exact: true
  },
  {
    id: 12,
    path: '/design-system/breadcrumbs',
    component: DesignSystem,
    exact: true
  },
  {
    id: 13,
    path: '/design-system/field',
    component: DesignSystem,
    exact: true
  },
  {
    id: 14,
    path: '/design-system/form-stepper',
    component: DesignSystem,
    exact: true
  },
  {
    id: 15,
    path: '/design-system/progress-bar',
    component: DesignSystem,
    exact: true
  },
  {
    id: 16,
    path: '/design-system/button',
    component: DesignSystem,
    exact: true
  },
  {
    id: 17,
    path: '/design-system/logo',
    component: DesignSystem,
    exact: true
  },
  {
    id: 18,
    path: '/design-system/typography',
    component: DesignSystem,
    exact: true
  },
  {
    id: 19,
    path: '/design-system/numpads',
    component: DesignSystem,
    exact: true
  },
  {
    id: 20,
    path: '/design-system/pattern',
    component: DesignSystem,
    exact: true
  },
  {
    id: 21,
    path: '/design-system/dropdown',
    component: DesignSystem,
    exact: true
  },
  {
    id: 22,
    path: '/design-system/form',
    component: DesignSystem,
    exact: true
  },
  {
    id: 23,
    path: '/design-system/footer',
    component: DesignSystem,
    exact: true
  },
  {
    id: 24,
    path: '/design-system/checkbox-toggle',
    component: DesignSystem,
    exact: true
  },
  {
    id: 25,
    path: '/design-system/header',
    component: DesignSystem,
    exact: true
  },
  {
    id: 26,
    path: '/design-system/upload-area',
    component: DesignSystem,
    exact: true
  },
  {
    id: 27,
    path: '/dashboard/home',
    component: DashboardHome,
    exact: true
  },
  {
    id: 28,
    path: '/helvetica-display',
    component: HelveticaDisplay,
    exact: true
  },
  {
    id: 29,
    path: '/accounts/casa',
    component: CasaHolding,
    exact: true
  },
  {
    id: 30,
    path: '/accounts/casa/detail',
    component: CasaDetail,
    exact: true
  },
  {
    id: 31,
    path: '/accounts/time-deposit',
    component: TimeDepositHolding,
    exact: true
  },
  {
    id: 32,
    path: '/accounts/time-deposit/detail',
    component: TimeDepositDetail,
    exact: true
  },
  {
    id: 33,
    path: '/services',
    component: Services,
    exact: true
  },
  {
    id: 34,
    path: '/services/local-currency-transfer',
    component: LocalCurrencyTransfer,
    exact: true
  },
  {
    id: 35,
    path: '/accounts/loan',
    component: LoanHolding,
    exact: true
  },
  {
    id: 36,
    path: '/accounts/loan/detail',
    component: LoanDetails,
    exact: true
  },
  {
    id: 37,
    path: '/accounts/loan/omnibus',
    component: Omnibus,
    exact: true
  },
  {
    id: 38,
    path: '/accounts/loan/list',
    component: ListLoan,
    exact: true
  },
  {
    id: 39,
    path: '/transaction-status/pending',
    component: Request,
    exact: true
  },
  {
    id: 40,
    path: '/transaction-status/for-repair',
    component: Request,
    // component: TransactionStatusForRepair,
    exact: true
  },
  {
    id: 41,
    path: '/transaction-status/successful',
    component: Request,
    exact: true
  },
  {
    id: 42,
    path: '/transaction-status/unsuccessful',
    component: Request,
    exact: true
  },
  {
    id: 43,
    path: '/transaction-status/all',
    component: Request,
    exact: true
  },
  {
    id: 44,
    path: '/transaction-status/forward-dated',
    component: Request,
    exact: true
  },
  {
    id: 45,
    path: '/request/repair',
    component: Request,
    exact: true
  },
  {
    id: 46,
    path: '/request/releaser',
    component: Request,
    exact: true
  },
  {
    id: 47,
    path: '/request/approver',
    component: Request,
    exact: true
  },
  {
    id: 48,
    path: '/request/approver/confirmation',
    component: RequestForApprovalConfirmation,
    exact: true
  },
  {
    id: 49,
    path: '/request/approver/detail',
    component: RequestForApprovalDetail,
    exact: true
  },
  {
    id: 50,
    path: '/transaction-status/transaction-detail',
    component: TransactionStatusDetailTransaction,
    exact: true
  },
  {
    id: 51,
    path: '/request/repair/detail',
    component: RequestForRepairDetail,
    exact: true
  },
  {
    id: 52,
    path: '/transaction-status/successful/detail',
    component: TransactionStatusDetailTransactionSuccessful,
    exact: true
  },
  {
    id: 53,
    path: '/request/repair/success',
    component: RequestForRepairSuccess,
    exact: true
  },
  {
    id: 54,
    path: '/request/repair/detail/edit',
    component: RequestForRepairDetailEdit,
    exact: true
  },
  {
    id: 55,
    path: '/request/releaser/detail',
    component: RequestReleaserDetail,
    exact: true
  },
  {
    id: 56,
    path: '/transaction-status/unsuccessful/detail',
    component: TransactionStatusUnsuccessfulDetail,
    exact: true
  },
  {
    id: 58,
    path: '/transaction-status/for-repair/detail',
    component: TransactionStatusForRepairDetail,
    exact: true
  },
  {
    id: 59,
    path: '/request/releaser/confirmation',
    component: RequestReleaserConfirmation,
    exact: true
  },
  {
    id: 60,
    path: '/services/top-up',
    component: TopUp,
    exact: true
  },
  {
    id: 62,
    path: '/services/bill-payment',
    component: BillPayment,
    exact: true
  },
  {
    id: 64,
    path: '/design-system/molecules-new',
    component: DesignSystem,
    exact: true
  },
  {
    id: 65,
    path: '/request/repair/all/for-approver',
    component: RequestAllForApproval,
    exact: true
  },
  {
    id: 66,
    path: '/request/repair/all/for-repair',
    component: RequestAllForRepair,
    exact: true
  },
  {
    id: 67,
    path: '/request/repair/all/for-releaser',
    component: RequestAllForReleaser,
    exact: true
  },
  {
    id: 68,
    path: '/request/repair/all/for-verify',
    component: RequestAllForVerify,
    exact: true
  },
  {
    id: 69,
    path: '/transaction-status/forwarted-dated/detail',
    component: TransactionStatusForwardDatedDetail,
    exact: true
  },
  {
    id: 70,
    path: '/transaction-status/transaction-detail-topup',
    component: TransactionStatusDetailTopup,
    exact: true
  },
  {
    id: 72,
    path: '/transaction-status/transaction-detail-billing',
    component: TransactionStatusDetailBilling,
    exact: true
  },
  {
    id: 73,
    path: '/request/reject-confirmation',
    component: RequestForRejectConfirmation,
    exact: true
  },
  {
    id: 74,
    path: '/request/for-verify/detail',
    component: RequestForVerifyDetail,
    exact: true
  },
  {
    id: 75,
    path: '/transaction-status/detail',
    component: TransactionStatusDetail,
    exact: true
  },
  {
    id: 76,
    path: '/request/approver/send-for-repair-confirmation',
    component: RequestForApprovalSendForRepairConfirmation,
    exact: true
  },
  {
    id: 77,
    path: '/request/verify',
    component: Request,
    exact: true
  },
  {
    id: 78,
    path: '/services/cheque-book-request',
    component: ChequeBook,
    exact: true
  },
  {
    id: 79,
    path: '/transaction-status/detail/topup',
    component: TransactionStatusDetailTopup,
    exact: true
  },
  {
    id: 80,
    path: '/transaction-status/detail/billing',
    component: TransactionStatusDetailBilling,
    exact: true
  },
  {
    id: 81,
    path: '/request/for-verify/confirmation',
    component: RequestForVerifyConfirmation,
    exact: true
  },
  {
    id: 82,
    path: '/services/bulk-payment',
    component: BulkPayment,
    exact: true
  },
  {
    id: 83,
    path: '/services/bulk-payment/detail',
    component: BulkPaymentDetailPage,
    exact: true
  },
  {
    id: 84,
    path: '/services/foreign-currency-transfer',
    component: ForeignCurrencyTransfer,
    exact: true
  },
  {
    id: 85,
    path: '/services/bulk-payment/record-detail',
    component: BulkPaymentRecordDetail,
    exact: true
  },
  {
    id: 86,
    path: '/transaction-status/detail/bulk',
    component: TransactionStatusDetailBulk,
    exact: true
  },
  {
    id: 87,
    path: '/services/favorites',
    component: FavoritesPage,
    exact: true
  },
  {
    id: 88,
    path: '/transaction-status/detail/chequebook',
    component: TransactionStatusDetailChequeBook,
    exact: true
  },
  {
    id: 89,
    path: '/transaction-status/detail/foreign-currency-transfer',
    component: TransactionStatusDetailForeignCurrencyTransfer,
    exact: true
  },
  {
    id: 90,
    path: '/accounts/valas/detail',
    component: ValasDetail,
    exact: true
  },
  {
    id: 91,
    path: '/accounts/valas/list',
    component: ValasList,
    exact: true
  },
  {
    id: 90,
    path: '/services/favorites/form',
    component: FavoritesForm,
    exact: true
  },
  {
    id: 91,
    path: '/services/recurring',
    component: RecurringPage,
    exact: true
  },
  {
    id: 92,
    path: '/services/recurring/form',
    component: RecurringForm,
    exact: true
  },
  {
    id: 92,
    path: '/services/recurring/detail',
    component: RecurringDetail,
    exact: true
  },
  {
    id: 93,
    path: '/transaction-status/detail/favorite',
    component: TransactionStatusDetailFavorite,
    exact: true
  },
  {
    id: 94,
    path: '/new-login',
    component: NewLogin,
    exact: true
  },
  {
    id: 95,
    path: '/logout',
    component: Logout,
    exact: true
  },
  {
    id: 82,
    path: '/services/bulk-payment/form',
    component: BulkPaymentUploadForm,
    exact: true
  }
];

export default AppRoutes;
