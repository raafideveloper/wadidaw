export default [
  {
    errorCode: '0',
    errorMessage: 'SpecialRateInfo',
    type: 'inline'
  },
  {
    errorCode: '1',
    errorMessage: 'ErrorDealNumberHasAlreadyBeenUsed',
    type: 'inline'
  },
  {
    errorCode: '2',
    errorMessage: 'ErrorYourRequestCannotBeProccessed',
    errorDescription: 'ErrorTransactionAmountDoesNotMatchWithDealNumber',
    type: 'popup'
  },
  {
    errorCode: '3',
    errorMessage: 'ErrorTransactionAmountDoesNotMatchWithDealNumber',
    type: 'inline'
  },
  {
    errorCode: '4',
    errorMessage: 'ErrorYourRequestCannotBeProccessed',
    errorDescription: 'ErrorTransactionDateIsInvalid',
    type: 'popup'
  },
  {
    errorCode: '5',
    errorMessage: 'ErrorTransactionDateIsInvalid',
    type: 'inline'
  },
  {
    errorCode: '6',
    errorMessage: 'ErrorDealNumberIsNotRegisteredInHost',
    type: 'inline'
  },
  {
    errorCode: '7',
    errorMessage: 'ErrorDealNumberIsNotUsingCurrencyMatrixByForex',
    type: 'inline'
  },
  {
    errorCode: '8',
    errorMessage: 'ErrorTransactionDateNeedsToBeImmediateOrToday',
    type: 'inline'
  },
  {
    errorCode: '9',
    errorMessage: 'ToUseSpecialRateTransactionDateNeedsToBeOnAWorkingDay',
    type: 'inline'
  },
  {
    errorCode: '10',
    errorMessage: 'ErrorTransactionDateMustBeToday',
    type: 'inline'
  },
  {
    errorCode: '11',
    errorMessage: 'ErrorUserCantChangeTransactionDateWithSpecialRate',
    type: 'inline'
  },
  {
    errorCode: '12',
    errorMessage: 'ConfirmTransferExceedsCutOffTime',
    type: 'inline'
  },
  {
    errorCode: '13',
    errorMessage: 'ConfirmYouTransactionDateWillBeMovedToNextWorkingDay',
    type: 'inline'
  },
  {
    errorCode: '14',
    errorMessage: 'WarningCutoffTimeExceededOn',
    type: 'inline'
  },
  {
    errorCode: '14b',
    errorMessage: 'WarningTransactionDateMustBeWorkingDay',
    type: 'inline'
  },
  {
    errorCode: '15',
    errorMessage: 'ErrorTransactionLimitAmountExceeded',
    type: 'inline'
  },
  {
    errorCode: '16',
    errorMessage: 'ErrorTransactionAmountIsOutOfBankTransactionLimitRange',
    type: 'inline'
  },
  {
    errorCode: '17',
    errorMessage: 'ErrorTransactionAmountIsOutOfMaximumAccountDebitLimitRange',
    type: 'inline'
  },
  {
    errorCode: '18',
    errorMessage:
      'ErrorTransactionAmountNeedBetweenMinimumTransactionLimitAndMaximumTransactionLimit',
    type: 'inline'
  },
  {
    errorCode: '19',
    errorMessage: 'ErrorTransactionAmountCantExceedMakersLimit',
    type: 'inline'
  },
  {
    errorCode: '20',
    errorMessage: 'ErrorTransactionAmountCantExceedMaximumLimitPerDay',
    type: 'inline'
  },
  {
    errorCode: '21',
    errorMessage: 'ErrorTransactionAmountCantExceedDailyServiceLimit',
    type: 'inline'
  },
  {
    errorCode: '22',
    errorMessage: 'ErrorTransactionAmountCantExceedGroupLimit',
    type: 'inline'
  },
  {
    errorCode: '23',
    errorMessage: 'ErrorApprovalMatrixForLLGHasNotBeenConfigured',
    errorDescription:
      'ErrorPleaseContactYourCorporateAdminToConfigureTheApprovalMatrix',
    type: 'popup'
  },
  {
    errorCode: '24',
    errorMessage: 'ErrorApprovalMatrixForRTGSHasNotBeenConfigured',
    errorDescription:
      'ErrorPleaseContactYourCorporateAdminToConfigureTheApprovalMatrix',
    type: 'popup'
  },
  {
    errorCode: '25',
    errorMessage: 'ErrorApprovalMatrixForOverbookingHasNotBeenConfigured',
    errorDescription:
      'ErrorPleaseContactYourCorporateAdminToConfigureTheApprovalMatrix',
    type: 'popup'
  },
  {
    errorCode: '26',
    errorMessage: 'ErrorApprovalMatrixForOverbookingHasNotBeenConfigured',
    errorDescription:
      'ErrorPleaseContactYourCorporateAdminToConfigureTheApprovalMatrix',
    type: 'popup'
  },
  {
    errorCode: '27',
    errorMessage: 'ErrorAmountRangeHasNotBeenSetup',
    errorDescription:
      'ErrorPleaseContactYourCorporateAdminToConfigureTheApprovalAmountRangeFirst',
    type: 'popup'
  },
  {
    errorCode: '28',
    errorMessage: 'ErrorUserNotEligible',
    errorDescription:
      'ErrorPleaseContactYourCorporateAdminRegardingYourAccountEligibility',
    type: 'popup'
  },
  {
    errorCode: '29',
    errorMessage: 'ErrorInvalidAccountNumber',
    type: 'inline'
  },
  {
    errorCode: '30',
    errorMessage: 'DailyLimitExceeded',
    errorDescription: 'PleaseRetryThisTransactionOnTheNextWorkingDay',
    type: 'popup'
  },
  {
    errorCode: '327',
    errorMessage: 'DailyLimitExceeded',
    errorDescription: '',
    type: 'popup'
  },
  {
    errorCode: '301',
    errorMessage: 'DailyLimitExceeded',
    type: 'inline'
  },
  {
    errorCode: '31',
    errorMessage: 'IncorrectEmailFormatKeyInProperlyFormattedEmailAddress',
    type: 'inline'
  },
  {
    errorCode: '32',
    errorMessage: 'PressSpacebarOrEnterToAddMoreThanOneEmail',
    type: 'inline'
  },
  {
    errorCode: '33',
    errorMessage: 'MobileNumberRegisteredOnGoJek',
    type: 'inline'
  },
  {
    errorCode: '34',
    errorMessage: 'UseYourShopeePayRegisteredMobileNumber',
    type: 'inline'
  },
  {
    errorCode: '35',
    errorMessage: 'DanaMobileNumberNotes',
    type: 'inline'
  },
  {
    errorCode: '36',
    errorMessage: 'PayProAccountNumberNotes',
    type: 'inline'
  },
  {
    errorCode: '37',
    errorMessage: 'DokuAccountNumberNotes',
    type: 'inline'
  },
  {
    errorCode: '38',
    errorMessage: 'PLNCustomerIDNotes',
    type: 'inline'
  },
  {
    errorCode: '39',
    errorMessage:
      'AstraPayMobileNumberIsYourMobileNumberThatRegisteredToAstraPay',
    type: 'inline'
  },
  {
    errorCode: '40',
    errorMessage: 'OvoMobileNumberNotes',
    type: 'inline'
  },
  {
    errorCode: '41',
    errorMessage: 'YouCanFindTheNumbersOnTheFrontFaceOfYourCreditCard',
    type: 'inline'
  },
  {
    errorCode: '42',
    errorMessage: 'InternetSubscriptionIDNotes',
    type: 'inline'
  },
  {
    errorCode: '43',
    errorMessage: 'TelephoneNumbersIsTelkomOrIndiHomeNumber',
    type: 'inline'
  },
  {
    errorCode: '44',
    errorMessage: 'FelloCustomerNumberNotes',
    type: 'inline'
  },
  {
    errorCode: '45',
    errorMessage: 'UseDashAsSeparatorBetweenNameAndPosition',
    type: 'inline'
  },
  {
    errorCode: '46',
    errorMessage: 'MasukkanNoYangSesuai',
    type: 'inline'
  },
  {
    errorCode: '47',
    errorMessage: 'NoYangDiMasukkanSalah',
    type: 'inline'
  },
  {
    errorCode: '48',
    errorMessage: 'TagihanSudahTerbayar',
    type: 'inline'
  },
  {
    errorCode: '49',
    errorMessage: 'PleaseEnterAValidPLNCustomerID_IDPEL',
    type: 'inline'
  },
  {
    errorCode: '50',
    errorMessage: 'ErrorRangeLimitApprovalMatrixNotFound',
    type: 'inline'
  },
  {
    errorCode: '51',
    errorMessage: 'ErrorAccountDebitLimitExceeded',
    type: 'inline'
  },
  {
    errorCode: '52',
    errorMessage: 'ErrorCorporateLimitAmountExceeded',
    type: 'inline'
  },
  {
    errorCode: '53',
    errorMessage: 'ErrorUserGroupLimitAmountExceeded',
    type: 'inline'
  },
  {
    errorCode: '54',
    errorMessage: 'ErrorMakerLimitExceeded',
    type: 'inline'
  },
  {
    errorCode: '55',
    errorMessage: 'RangeLimitPersetujuanTidakDitemukan',
    type: 'inline'
  },
  {
    errorCode: '56',
    errorMessage: 'TransaksiMelebihiBatasNominalRekeningDebit',
    type: 'inline'
  },
  {
    errorCode: '57',
    errorMessage: 'NominalTransaksiDiLuarBatasNominalTransaksiBank',
    type: 'inline'
  },
  {
    errorCode: '58',
    errorMessage: 'TransaksiMelebihiBatasNominalLimitHarianGroupCorporate',
    type: 'inline'
  },
  {
    errorCode: '59',
    errorMessage: 'TransaksiMelebihiBatasNominalLimitHarianUserGroup',
    type: 'inline'
  },
  {
    errorCode: '60',
    errorMessage: 'NominalTansaksiMelebihiBatasNominalMaker',
    type: 'inline'
  },
  {
    errorCode: '61',
    errorMessage: 'UseDashAsSeparatorBetweenNameAndPosition',
    type: 'inline'
  },
  {
    errorCode: '62',
    errorMessage: 'InvalidBillingNumber',
    type: 'inline'
  },
  {
    errorCode: '63',
    errorMessage: 'TheBillHasBeenPaid',
    type: 'inline'
  },
  {
    errorCode: '64',
    errorMessage:
      'InvalidInsuranceAccountNumberPleaseInputValidInsuranceAccountNumber',
    type: 'inline'
  },
  {
    errorCode: '65',
    errorMessage:
      'InvalidSecurityCompanyAccountNumberPleaseInputValidSecurityCompanyAccountNumber',
    type: 'inline'
  },
  {
    errorCode: '66',
    errorMessage: 'IncorrectBillingNumber',
    type: 'inline'
  },
  {
    errorCode: '67',
    errorMessage:
      'InvalidMeterIDPELPLNNumberPleaseInputValidMeterIDPELPLNNumber',
    type: 'inline'
  },
  {
    errorCode: '68',
    errorMessage: 'YouHaveEnteredWrongNumberPleaseInputCorrectNumber',
    type: 'inline'
  },
  {
    errorCode: '69',
    errorMessage: 'InvalidOVOMobileNumber',
    type: 'inline'
  },
  {
    errorCode: '70',
    errorMessage: 'ErrorMaximumFutureDateExceeded',
    type: 'inline'
  },
  {
    errorCode: '71',
    errorMessage: 'TransactioCantbeProcessedPleaseContactPermataBank',
    type: 'inline'
  },
  {
    errorCode: '72',
    errorMessage: 'ErrorInvalidAstraPayNumber',
    type: 'inline'
  },
  {
    errorCode: '73',
    errorMessage: 'TransactionCantBeProcessedAmount',
    type: 'inline'
  },
  {
    errorCode: '74',
    errorMessage: 'TransactionDateMustBeTodayForSpecialRate',
    type: 'inline'
  },
  {
    errorCode: '75',
    errorMessage: 'ToUseSpecialRateTransactionDateNeedsToBeOnAWorkingDay',
    type: 'inline'
  },
  {
    errorCode: '9090',
    errorMessage: 'ErrorMandatoryField',
    type: 'inline'
  },
  {
    errorCode: '1311',
    errorMessage: 'MobileLegendsUserIDNotes',
    type: 'inline'
  },
  {
    errorCode: '101',
    errorMessage: 'YouHaveEnteredAnInvalidTelephoneOrIndiHomeNumber',
    type: 'inline'
  },
  {
    errorCode: '102',
    errorMessage: 'InvalidTelephoneNumberPleaseInputValidTelephoneNumber',
    type: 'inline'
  },
  {
    errorCode: '103',
    errorMessage: 'TheBillHasBeenPaidPleaseMakeOtherPaymentTransactions',
    type: 'inline'
  },
  {
    errorCode: '104',
    errorMessage: 'PleaseEnterValidVirtualAccountNumber',
    type: 'inline'
  },
  {
    errorCode: '105',
    errorMessage:
      'IncorrectVirtualAccountNumberPleaseReTransactionByEnteringTheCorrectVirtualAAccountNumber',
    type: 'inline'
  },
  {
    errorCode: '106',
    errorMessage: 'InvalidCreditCardNumberPermata',
    type: 'inline'
  },
  {
    errorCode: '107',
    errorMessage: 'InvalidCreditCardNumberPermata',
    type: 'inline'
  },
  {
    errorCode: '108',
    errorMessage: 'InvalidMobileNumber',
    type: 'inline'
  },
  {
    errorCode: '109',
    errorMessage: 'Billisalreadypaid',
    type: 'inline'
  },
  {
    errorCode: '110',
    errorMessage: 'InvalidInternetSubscriptionID',
    type: 'inline'
  },
  {
    errorCode: '111',
    errorMessage: 'Transactioncantbeprocessed',
    type: 'inline'
  },
  {
    errorCode: '112',
    errorMessage: 'CutOffTimeExceeded',
    type: 'inline'
  },
  {
    errorCode: '113',
    errorMessage: 'ErrorTransactionDateMustBeWorkingDay',
    type: 'inline'
  },
  {
    errorCode: '114',
    errorMessage: 'StartDateMustBeSelected',
    type: 'inline'
  },
  {
    errorCode: '115',
    errorMessage: 'ErrorStartDateSameWithTransactionDate',
    type: 'inline'
  },
  {
    errorCode: '116',
    errorMessage: 'ErrorStartDateSmallerThanTransactionDate',
    type: 'inline'
  },
  {
    errorCode: '117',
    errorMessage: 'ErrorStartDateGreaterThanEndDate',
    type: 'inline'
  },
  {
    errorCode: '118',
    errorMessage: 'ErrorEndDateHaveToBeSameWithStartDate',
    type: 'inline'
  },
  {
    errorCode: '119',
    errorMessage: 'ExpiryDateMustBeSelected',
    type: 'inline'
  },
  {
    errorCode: '120',
    errorMessage: 'InvalidCableSubscriptionId',
    type: 'inline'
  },
  {
    errorCode: '121',
    errorMessage: 'InvalidWaterProviderID',
    type: 'inline'
  },
  {
    errorCode: '122',
    errorMessage: 'InvalidValidPLNCustomerID_IDPEL',
    type: 'inline'
  },
  {
    errorCode: '123',
    errorMessage: 'InvalidDanaIDMobileNumber',
    type: 'inline'
  },
  {
    errorCode: '124',
    errorMessage: 'ErrorTicketPaymentCode',
    type: 'inline'
  },
  {
    errorCode: '125',
    errorMessage: 'AccountMustBeSelected',
    type: 'inline'
  },
  {
    errorCode: '126',
    errorMessage: 'QuantityIsMandatory',
    type: 'inline'
  },
  {
    errorCode: '127',
    errorMessage: 'QuantityMustBeNumeric',
    type: 'inline'
  },
  {
    errorCode: '128',
    errorMessage: 'ApproverNotConfiguredTitle',
    errorDescription: 'ApproverNotConfiguredDesc',
    type: 'popup'
  },
  {
    errorCode: '129',
    errorMessage: 'MismatchedBeneficiaryName',
    type: 'inline'
  },
  {
    errorCode: '130',
    errorMessage: 'DuplicatedCustomerReferenceDetail',
    type: 'inline'
  },
  {
    errorCode: '131',
    errorMessage: 'IgnoreDuplicatedCustomer',
    errorDescription: 'IgnoreDuplicatedCustomerDesc',
    type: 'popup'
  },
  {
    errorCode: '132',
    errorMessage: 'TransactionExecutionFailedTitle',
    errorDescription: 'TransactionExecutionFailedDesc',
    type: 'popup'
  },
  {
    errorCode: '133',
    errorMessage: 'DealNumberIsNotFound',
    type: 'inline'
  },
  {
    errorCode: '134',
    errorMessage: 'DealNumberisnotusingcurrencymatrixbyForexCrossForex',
    type: 'inline'
  },
  {
    errorCode: '135',
    errorMessage:
      'TransactionAmountNeedToBeInBetweenMinimumTransactionLimitAndMaximumTransactionLimit',
    type: 'inline'
  },
  {
    errorCode: '136',
    errorMessage: 'MaxLimitExceeded',
    type: 'inline'
  },
  {
    errorCode: '137',
    errorMessage: 'TransactionAmountIsBelowTheMinimumTransactionLimit',
    type: 'inline'
  },
  {
    errorCode: '138',
    errorMessage: 'TransactionAmountIsOutOfTheMaximumTransactionLimit',
    type: 'inline'
  },
  {
    errorCode: '139',
    errorMessage: 'TransactionAmountCantExceedCorporateDailyLimit',
    type: 'inline'
  },
  {
    errorCode: '140',
    errorMessage: 'TransactionAmountCantExceedMaximumOnlineDailyLimit',
    type: 'inline'
  },
  {
    errorCode: '141',
    errorMessage: 'TheSelectedTransferTypeDoesntMatchTheAmountEntered',
    type: 'inline'
  },
  {
    errorCode: '142',
    errorMessage: 'DailyLimitAmountExceeded',
    type: 'inline'
  },
  {
    errorCode: '143',
    errorMessage: 'ThisTransactionCannotBeProceeded',
    errorDescription: 'NoEligibleApproverPleaseContactYourCorporateAdmin',
    type: 'popup'
  },
  {
    errorCode: '144',
    errorMessage: 'CaptchaCodeDoesNotMatchWithTheDisplay',
    type: 'inline'
  },
  {
    errorCode: '145',
    errorMessage: 'ErrorLoginFailedInvalidIDAndPassword',
    type: 'inline'
  },
  {
    errorCode: '146',
    errorMessage: 'ErrorAccountnotfound',
    type: 'inline'
  }
];
