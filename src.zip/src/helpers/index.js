/* eslint-disable spaced-comment */
/* eslint-disable react/prop-types */
/* eslint-disable react/jsx-one-expression-per-line */
/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable guard-for-in */
/* eslint-disable no-restricted-syntax */
/* eslint-disable prettier/prettier */
// PLUGINS
import { disablePageScroll, enablePageScroll } from 'scroll-lock-m5';
import { multiLanguage, _getBahasa } from 'helpers/ConfigLanguage';
import errorMessages from 'config/errors/index';

// import publicHolidays from "assets/dummy-data/public-holiday.json";
import React, { useEffect } from 'react';
import Prism from "prismjs";

// ==> START checkOS
export function getOSCheck() {
  let OSIs = 'desktop-browser';

  if (navigator.userAgent.match(/Android/i)) {
    OSIs = 'android-browser';
  } else if (navigator.userAgent.match(/BlackBerry/i)) {
    OSIs = 'blackberry-browser';
  } else if (navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
    OSIs = 'ios-browser';
  } else if (navigator.userAgent.match(/IEMobile/i)) {
    OSIs = 'windows-phone-browser';
  }

  return OSIs;
}

export function viewOrientation() {
  let orientation = '';
  if (window.matchMedia("(orientation: portrait)").matches) {
    orientation = "portrait";
  }

  if (window.matchMedia("(orientation: landscape)").matches) {
    orientation = "landscape";
  }
  return orientation;
}

export function mobileOSCheck() {
  let mobileOSIs = 'desktop-browser';
  const HTMLElement = document.getElementsByTagName('html')[0];
  if (navigator.userAgent.match(/Android/i)) {
    mobileOSIs = 'android-browser';
  } else if (navigator.userAgent.match(/BlackBerry/i)) {
    mobileOSIs = 'blackberry-browser';
  } else if (navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
    mobileOSIs = 'ios-browser';
  } else if (navigator.userAgent.match(/IEMobile/i)) {
    mobileOSIs = 'windows-phone-browser';
  }
  HTMLElement.classList.add(mobileOSIs);
}
mobileOSCheck();
// ==> END checkOS

// ==> START delay
export function delay(duration) {
  // eslint-disable-next-line consistent-return
  return new Promise((resolve, reject) => {
    // eslint-disable-next-line prefer-promise-reject-errors
    if (!duration) return reject('Duration is not set!');
    setTimeout(() => resolve(), duration);
  });
}
// ==> END delay

// ==> START removeScrollOnPopup
let removeScrollStatus = false;
export function removeScrollOnPopup(status) {
  // android case : default value is unused due to bug no 45627
  let removeScroll = '';
  if (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream) {
    removeScroll = 'remove-scroll-ios';
  }
  if (status) {
    if (window.innerWidth <= 960) {
      if (removeScroll !== '') {
        document.body.classList.remove('scroll-off');
        document.body.classList.remove('remove-scroll');
        document.body.classList.remove('remove-scroll-ios');
        setTimeout(() => {
          document.body.classList.add(removeScroll);
        }, 200);
      } else {
        document.body.classList.add('scroll-off');
      }
    } else {
      document.body.classList.add('scroll-off');
    }
    removeScrollStatus = true;
    delay(300).then(() => {
      removeScrollStatus = false;
    });
  } else if (!removeScrollStatus) {
    // console.log('masuk else')
    document.body.classList.remove('scroll-off');
    document.body.classList.remove('remove-scroll');
    document.body.classList.remove('remove-scroll-ios');
    enablePageScroll();
  }
}
// ==> END removeScrollOnPopup

// ==> START removeScrollInputDropdown
export function removeScrollInputDropdown(status) {
  let removeScroll = 'remove-scroll';
  if (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream) {
    removeScroll = 'remove-scroll-dropdown-ios';
  }
  document.body.classList.remove('remove-scroll');
  document.body.classList.remove('remove-scroll-dropdown-ios');
  enablePageScroll();
  if (status) {
    if (window.innerWidth <= 960) {
      document.body.classList.add(removeScroll);
    } else if (window.innerWidth <= 1200) {
      delay(300).then(() => {
        disablePageScroll();
      });
    } else {
      disablePageScroll();
    }
  } else if (window.innerWidth <= 1200) {
    delay(50).then(() => {
      document.body.classList.remove('remove-scroll');
      document.body.classList.remove('remove-scroll-dropdown-ios');
      enablePageScroll();
    });
  }
}
// ==> END removeScrollInputDropdown

// ==> START formatRupiah
export function formatRupiah(amount) {
  const numberString = amount.toString();
  const split = numberString.split('.');
  const overage = split[0].length % 3;
  const thousand = split[0].substr(overage).match(/\d{1,3}/gi);
  let decimal = split[1];
  let rupiah = split[0].substr(0, overage);

  if (thousand) {
    const separator = overage ? ',' : '';
    rupiah += separator + thousand.join(',');
  }

  if (decimal === undefined) {
    decimal = '00';
  }

  const formatted = `${rupiah}.${decimal}`;
  return `Rp ${formatted}`;
}
// ==> END formatRupiah

// ==> START formatRupiahRMG
export function formatRupiahRMG(amount) {
  const numberString = amount.toString();
  const split = numberString.split('.');
  const formatted = split[0].replace(/(\d)(?=(\d{3})+$)/g, '$&,');

  if (split[1]) {
    return `Rp ${formatted}.${split[1]}`;
  }

  return `Rp ${formatted}.00`;
}
// ==> END formatRupiahRMG

// ==> START formatNoCurrency
export function formatNoCurrency(amount) {
  if (amount !== '-') {
    const numberString = amount.toString();
    const split = numberString.split('.');
    const formatted = split[0].replace(/(\d)(?=(\d{3})+$)/g, '$&,');

    if (split[1]) {
      return `${formatted}.${split[1]}`;
    }

    return numberString === '' || numberString === '0' ? `0.00` : `${formatted}.00`;
  }

  return amount;

}
// ==> END formatNoCurrency

// ==> START formatThousandRMG
export function formatThousandRMG(amount) {
  const numberString = amount.toString();
  const formatted = numberString.replace(/(\d)(?=(\d{3})+$)/g, '$&.');
  return formatted;
}
// ==> END formatThousandRMG

// ==> START smoothScroll
export function smoothScroll(element, duration, offset = 0) {


  /* --------------------
  | add override class for active step
  -------------------- */
  // console.log('>>==---->> element id : ',element.id)
  let smoothScrollEnded;
  if (document.getElementsByClassName('m-stepper').length) {
    smoothScrollEnded = false;
    if (element) {
      const elId = element.id;
      const stepperEl = document.querySelectorAll(`[section-id="${elId}"]`)[0].parentNode.parentNode.parentNode;
      const targetStep = document.querySelectorAll(`[section-id="${elId}"]`)[0].parentNode;
      const prevCurrent = document.querySelectorAll(`.strict-current`);
      // at start of smootScroll, clean previous override class & add on the clicked step
      if (!smoothScrollEnded) {
        if (prevCurrent.length) {
          prevCurrent[0].classList.remove('strict-current');
        }
        stepperEl.classList.add('strict-highlight');
        targetStep.classList.add('strict-current');
      }
    }
  }
  /* -------------------- */


  // which element do you want to scroll to
  const target = element;
  // that element's y position
  const targetPosition =
    target.getBoundingClientRect().top + window.scrollY + offset;

  // current window position
  const windowPosition = window.scrollY;

  // distance between curent window position and the target
  const distance = targetPosition - windowPosition;

  /* console.log('===============================');
  console.log('>>==---->> windowPosition : ',windowPosition);
  console.log('>>==---->> targetPosition : ',targetPosition);
  console.log('>>==---->> distance : ',distance);
  console.log('-------------------------------'); */

  let startTime = null;

  function animation(currentTime) {
    if (!startTime) {
      startTime = currentTime;
    }
    const timeElapsed = currentTime - startTime;
    const run = Math.easeInOutQuad(
      timeElapsed,
      windowPosition,
      distance,
      duration
    );
    const frame = Math.round(run);
    // console.log('>>==---->> window.scrollTo : ',frame);
    window.scrollTo(0, frame);
    if (timeElapsed < duration && frame !== targetPosition) {
      requestAnimationFrame(animation);
    }
    else if (timeElapsed >= duration && frame !== targetPosition) {
      if (
        (distance < 0 && frame > targetPosition) ||
        (distance > 0 && frame < targetPosition)
      ) {
        window.scrollTo(0, targetPosition);
      }
    }


    /* --------------------
    | remove override class for active step
    -------------------- */
    // console.log(frame,' / ',targetPosition)
    if (document.getElementsByClassName('m-stepper').length) {
      if (
        Math.abs(frame - targetPosition) < 5 &&
        !smoothScrollEnded
      ) {
        // console.log('>>==---->> end of smoothScroll')
        smoothScrollEnded = true;
        // time out to make sure animation already ended before cleaning up
        setTimeout(() => {
          const stepperEl = document.querySelectorAll(`.strict-highlight`);
          if (stepperEl.length) {
            stepperEl[0].classList.remove('strict-highlight');
          }
          const prevCurrent = document.querySelectorAll(`.strict-current`);
          if (prevCurrent.length) {
            prevCurrent[0].classList.remove('strict-current');
          }
        }, 100);
      }
    }
    /* -------------------- */
  }

  // NOTE : timeout to make sure all rendering done before running the scroll animation
  setTimeout(() => {
    requestAnimationFrame(animation);
  }, 100);
}

// t: current time, b: start value, c: change in value, d: duration
Math.easeInOutQuad = function(t, b, c, d) {
  // eslint-disable-next-line no-param-reassign
  t /= d / 2;
  if (t < 1) return (c / 2) * t * t + b;
  t--;
  return (-c / 2) * (t * (t - 2) - 1) + b;
};
// ==> END smoothScroll

// ==> START formatMoney
export function formatMoney(amount, symbol, mantissa = true, withoutCurrency = true, checkLanguage = false) {
  if (!symbol) return '';
  const numberString = amount.toString();
  const split = numberString.split('.');
  const overage = split[0].length % 3;
  const thousand = split[0].substr(overage).match(/\d{1,3}/gi);
  let money = split[0].substr(0, overage);

  const separatorByLanguage = checkLanguage ? _getBahasa() === 'en' ? ',' : '.' : ',';
  if (thousand) {
    const separator = overage ? separatorByLanguage : '';
    money += separator + thousand.join(separatorByLanguage);
  }

  let formatted = money;

  if (mantissa) {
    formatted = `${money}`;
  }

  let symbolSign = '';
  switch (symbol) {
    case 'IDR':
      // symbolSign = 'Rp';
      symbolSign = 'IDR';
      break;
    default:
      symbolSign = symbol;
      break;
  }

  // nambah spasi sebelum angka
  return `${withoutCurrency ? `${symbolSign}${` `}` : ''}${formatted}${split[1] ? `.${split[1]}` : '.00'}`;
}
// ==> END formatMoney

// ==> START removeAllHyphen
const removeAllHyphen = (keyword) => {
  return keyword
    .replace(/(\d)-/g, '$1')
    .replace(/-(\d)/g, '$1')
    .replace(/(\d)-(\d)-/g, '$1$2')
    .replace(/(\d)-(\d)/g, '$1$2');
};
export { removeAllHyphen };
// ==> END removeAllHyphen

// ==> START highlightSearchKeyword
export const highlightSearchKeyword = (keyword, result) => {
  if (keyword && keyword.length >= 3) {
    keyword = removeAllHyphen(keyword);
    const noHypResult = removeAllHyphen(result);

    if (noHypResult.toLowerCase().indexOf(keyword.toLowerCase()) > -1) {
      const resIsNumber = !isNaN(noHypResult);
      /* console.log('keyword : ',keyword)
      console.log('result : ',result,' / ',noHypResult)
      console.log('resIsNumber : ',resIsNumber) */

      let start = result.toLowerCase().indexOf(keyword.toLowerCase());
      if (resIsNumber) {
        start = noHypResult.indexOf(keyword);
      }
      const length = keyword.length;
      let end = start + length;
      if (resIsNumber) {
        start += Math.floor(start / 4);
        end += Math.floor((end - 1) / 4);
      }
      /* console.log('start : ',start)
      console.log('end : ',end) */

      const kw1 = result.substring(0, start);
      const kw2 = result.substring(end);
      const bold = `<strong>${result.substring(start, end)}</strong>`;
      const highlighted = kw1 + bold + kw2;
      /* console.log('kw1 : ',kw1)
      console.log('kw2 : ',kw2)
      console.log('bold : ',bold) */
      return highlighted;
    }

    return result;

  }

  return result;
};
// ==> END highlightSearchKeywordformatMoney

// ==> START formatNumberCard
export const formatNumberCard = (key) => {
  const parts = [];
  for (let i = 0, len = key.length; i < len; i += 4) {
    parts.push(key.substring(i, i + 4));
  }
  return parts.join('-');
};
// ==> END formatNumberCard

// ==> START checkNumber
export const checkNumber = (value) => {
  return Math.floor(value) === value;
};
// ==> END checkNumber

// ==> START formatPhoneNumber
export function formatPhoneNumber(number) {
  const space = /^\s*$/;
  let formatted = number;
  if (!space.test(number)) {
    formatted = formatted
      .replace(/\s/g, '')
      .match(/.{1,4}/g)
      .join(' ');
  }
  return formatted;
}
// ==> END formatPhoneNumber

// ==> START formatNumberCardInput
export function formatNumberCardInput(number) {
  const space = /^-*$/;
  let formatted = number;
  if (!space.test(number)) {
    formatted = formatted
      .replace(/-/g, '')
      .match(/.{1,4}/g)
      .join('-');
  }
  return formatted;
}
// ==> END formatNumberCardInput

// ==> START formatPercentage
export function formatPercentage(number) {
  const value = `${parseFloat(number).toFixed(2)}%`;
  return value;
}

//  ==> START formatDate
export function formatDate(value, format) {
  const date = new Date(value);
  const m = [];
  m[0] = multiLanguage.January;
  m[1] = multiLanguage.February;
  m[2] = multiLanguage.March;
  m[3] = multiLanguage.April;
  m[4] = multiLanguage.May;
  m[5] = multiLanguage.June;
  m[6] = multiLanguage.July;
  m[7] = multiLanguage.August;
  m[8] = multiLanguage.September;
  m[9] = multiLanguage.October;
  m[10] = multiLanguage.November;
  m[11] = multiLanguage.December;
  const month = m[date.getMonth()];
  const day = (`0${date.getDate()}`).slice(-2);
  const year = date.getFullYear();
  const hour = date.getHours();
  const minute = date.getMinutes();
  const second = date.getSeconds();
  if (format === 'd MM YYYY') {
    return `${day} ${month} ${year}`;
  }
  if (format === 'd MM') {
    return `${day} ${month}`;
  }
  if (format === 'd MM YYYY | HH:MM:SS') {
    return `${day} ${month.substring(0, 3)} ${year} | ${(`0${hour}`).slice(-2)}:${(`0${minute}`).slice(-2)}:${(`0${second}`).slice(-2)}`;
  }
  if (format === 'HH:MM:SS') {
    return `${(`0${hour}`).slice(-2)}:${(`0${minute}`).slice(-2)}:${(`0${second}`).slice(-2)}`;
  }
  if (format === 'd M YYYY') {
    return `${day} ${month.substring(0, 3)} ${year}`;
  }
  return '';
}
// ==> END formatDate

// ==> START dayDiff
export function dayDiff(startDate, endDate) {
  const oneDay = 24 * 60 * 60 * 1000;
  const dayDiffs = Math.round(Math.abs((endDate - startDate) / oneDay));
  return dayDiffs;
}

// ==> START checkPublicHoliday
export function checkPublicHoliday(publicHolidaysData, date) {
  for (let i = 0; i < publicHolidaysData.length; i++) {
    if (
      date.getDate() === new Date(publicHolidaysData[i].date).getDate() &&
      date.getMonth() === new Date(publicHolidaysData[i].date).getMonth() &&
      date.getFullYear() === new Date(publicHolidaysData[i].date).getFullYear()
    ) {
      return true;
    }
  }
  return false;
}

// ==> START removeExtentionFile
export function removeExtentionFile(fileNames) {
  const filenameText = fileNames.replace(/\.[^/.]+$/, '');

  return filenameText;
}

// ==> START GenerateRandomPDF
export function generateRandomDataPDF(length) {
  const result = [];
  for (let i = 0; i < length; i++) {
    result.push({
      title: i % 2 === 0 ? 'Debit Advice' : 'CreditAdvice',
      type: i % 2 === 0 ? 'debit' : 'credit',
      transaction: {
        transactionDate: '24 Jun 2021',
        transactionNumber: '1239-2913-0120',
        transactionChannel: 'Permatae-Business',
        transactionCustomerNumber: 'INVOICEA001'
      },
      beneficiary: {
        beneficiaryNumber: '0080-1439-5901',
        beneficiaryName: 'PT Toyota Motor Manufacturing Indonesia',
        beneficiaryBank: 'Citibank'
      },
      account: {
        accountNumber: '0080-1439-5901',
        accountName: 'PT Toyota Motor Manufacturing Indonesia',
        accountBank: 'PermataBank'
      },
      remitter: {
        remitterNumber: '0080-1439-5901',
        remitterName: 'PT Toyota Motor Manufacturing Indonesia',
        remitterBank: 'Citibank'
      },
      payment: {
        paymentAmount: 1415000,
        paymentType: 'LLG'
      },
      description:
        "Payroll Payment Confirmation June 2021 with reference number #123488881929 '"
    });
  }
  return result;
}
// ==> END GenerateRandomPDF

// ==> START SortingArray
export function stringSort(arr, sort, desc, includeFav) {
  /* console.log('============')
  console.log('arr : ',arr)
  console.log('sort : ',sort)
  console.log('desc : ',desc)
  console.log('includeFav : ',includeFav)
  console.log('============') */
  if (sort === 'secondary') {
    sort = 'accountName';
  }

  // not sorted : fav, sorted : not fav
  const arrNotSorted = [];
  let arrSorted = [];

  if (!includeFav) {
    arr.forEach((data, index) => {
      if (data.favorite === true || data.closeCutOffTime === true) {
        arrNotSorted.push(data);
      }
      else {
        arrSorted.push(data);
      }
    });
  }
  else {
    arrSorted = JSON.parse(JSON.stringify(arr));
  }

  const arrCurrency1 = [];
  const arrCurrency2 = [];
  const arrCurrencyRemaining = [];
  if (sort === 'accountCurrency') {
    arrSorted.forEach((data, index) => {
      if (data.accountCurrency === 'IDR') {
        arrCurrency1.push(data);
      }
      else if (data.accountCurrency === 'USD') {
        arrCurrency2.push(data);
      }
      else {
        arrCurrencyRemaining.push(data);
      }
    });
  }

  if (
    sort === 'accountBalance' ||
    sort === 'accountInterestRate'
  ) {
    arrSorted.sort(function(a, b) {
      if (parseFloat(a[sort]) < parseFloat(b[sort])) return -1;
      if (parseFloat(a[sort]) > parseFloat(b[sort])) return 1;
      return 0;
    });
  }
  else if (sort === 'accountCurrency') {
    arrSorted.length = 0;
    arrCurrency1.sort(function(a, b) {
      if (a[sort] < b[sort]) return -1;
      if (a[sort] > b[sort]) return 1;
      return 0;
    });
    arrCurrency2.sort(function(a, b) {
      if (a[sort] < b[sort]) return -1;
      if (a[sort] > b[sort]) return 1;
      return 0;
    });
    arrCurrencyRemaining.sort(function(a, b) {
      if (a[sort] < b[sort]) return -1;
      if (a[sort] > b[sort]) return 1;
      return 0;
    });
  }
  else if (sort === 'destination') {
    arrSorted.sort(function(a, b) {
      if (a[sort].customerName < b[sort].customerName) return -1;
      if (a[sort].customerName > b[sort].customerName) return 1;
      return 0;
    });
  }
  else if (sort === 'createdBy') {
    arrSorted.sort(function(a, b) {
      if (a[sort].fullName < b[sort].fullName) return -1;
      if (a[sort].fullName > b[sort].fullName) return 1;
      return 0;
    });
  }
  else {
    arrSorted.sort(function(a, b) {
      if (a[sort] < b[sort]) return -1;
      if (a[sort] > b[sort]) return 1;
      return 0;
    });
  }

  if (desc) {
    arrSorted.reverse();
    arrCurrency1.reverse();
    arrCurrency2.reverse();
    arrCurrencyRemaining.reverse();
  }

  let arrAll;
  // the following logic only affect currency sorting
  // - currency asc : IDR - USD - others ascending
  // - currency desc : others descending - USD - IDR
  if (desc) {
    arrAll = arrNotSorted.concat(arrSorted, arrCurrencyRemaining, arrCurrency2, arrCurrency1);
  }
  else {
    arrAll = arrNotSorted.concat(arrSorted, arrCurrency1, arrCurrency2, arrCurrencyRemaining);
  }

  /* console.log('~~~~~~~~~~~~')
  for (let i=0 ; i<arrAll.length ; i++){
    console.log(arrAll[i].accountName + ' / ' + arrAll[i].accountCurrency + ' / ' + arrAll[i].favorite)
  }
  console.log('~~~~~~~~~~~~') */
  return arrAll;
}
// ==> END SortingArray

// ==> START Format Number
export function formatNumberCurrency(currencyNumber, endZeros) {
  const numberString = String(currencyNumber)
    .replace(/[^.\d]/g, '')
    .toString();
  const split = numberString.split('.');
  const sisa = split[0].length % 3;
  const ribuan = split[0].substring(sisa).match(/\d{3}/gi);
  let rupiah = split[0].substring(0, sisa);
  if (ribuan) {
    const separator = sisa ? ',' : '';
    rupiah += separator + ribuan.join(',');
  }
  // rupiah = split[1] !== undefined ? `${rupiah}.00` : `${rupiah}.00`; // ${split[1]}
  if (endZeros) {
    rupiah = (rupiah) ? `${rupiah}.00` : '';
  } else {
    rupiah = (rupiah) ? `${rupiah}` : '';
  }
  // rupiah = (rupiah) ? `${rupiah}.00` : '';
  const resultConvert = rupiah.charAt(0) === '0' ? rupiah.slice(1) : rupiah;
  return resultConvert;
}
// ==> END Format Number

// ==> START convert string currency to number
export function stringCurrencyToNumber(strCurr) {
  const numCurr = strCurr.replace(',', '');
  return parseInt(numCurr);
}
// ==> END stringCurrencyToNumber

// ==> START Hyphenate
export function hyphenate(str, nchar) {
  const ele = String(str)
    .split('-')
    .join('');
  const reg = new RegExp(`.{1,${nchar}}`, 'g');
  return ele.match(reg).join('-');
}
// ==> END Hyphenate

// ==> START urlPath
export function urlPath() {
  return window.location.pathname;
}
// ==> END urlPath

// ==> START Striptags
export function striptags(str) {
  return String(str).replace(/(<([^>]+)>)/gi, "");
}
// ==> END Striptags
export function resizableInput(el, factor) {
  console.log({ el, factor })
  // const int = Number(factor) || 7.7;
  const int = 9.1;
  function resize() {
    el.style.width = `${(
      el.value.length +
      (el.value.match(/@/g) || []).length * 0.91 +
      (el.value.match(/[m]/g) || []).length * 0.52 +
      (el.value.match(/[w]/g) || []).length * 0.36 +
      (el.value.match(/[M]/g) || []).length * 0.53 +
      (el.value.match(/[W]/g) || []).length * 0.68 +
      (el.value.match(/[i,I,j,l]/g) || []).length * -0.56 +
      (el.value.match(/[.]/g) || []).length * -0.5 +
      (el.value.match(/[f,t]/g) || []).length * -0.37 +
      (el.value.match(/[1]/g) || []).length * -0.22 +
      (el.value.match(/(?![M,W,I])[A-Z]/g) || []).length * 0.2
    ) * int + 24}px`
  }
  const e = 'keyup,keypress,focus,blur,change'.split(',');
  for (const i in e) el.addEventListener(e[i], resize, false);
  resize();
}

export function removeSpecialChars(str) {
  // return String(str).replace(/[^\w\s]/gi, "");
  return String(str).replace(/[^0-9a-z]/gi, '');
}

export function forceNumeric(str) {
  return String(str).replace(/[^0-9]/gi, '');
}

export function scrollTo(offset, smoothness = true, callback) {
  const fixedOffset = offset.toFixed();
  const onScroll = function() {
    if (window.pageYOffset.toFixed() === fixedOffset) {
      window.removeEventListener('scroll', onScroll)
      callback()
    }
  }

  window.addEventListener('scroll', onScroll)
  onScroll()

  if (smoothness) {
    window.scrollTo({
      top: offset,
      behavior: 'smooth'
    })
  } else {
    window.scrollTo({
      top: offset
    })
  }
}

export function upperCase(str) {
  return str.toUpperCase();
}

export function removeItem(arr, id) {
  return arr.filter(item => item.id !== id);
}

export function getHashString() {
  const hashValue = window.location.hash;
  const hashString = hashValue.replace('#!', '');
  return hashString;
}

export function getHash(aURL) {
  aURL = aURL || window.location.href;

  const vars = {};
  const hashes = aURL.slice(aURL.indexOf('#') + 1).split('&');

  for (let i = 0; i < hashes.length; i++) {
    const hash = hashes[i].split('=');

    if (hash.length > 1) {
      vars[hash[0]] = hash[1];
    } else {
      vars[hash[0]] = null;
    }
  }

  return vars;
}

export function capitalize(s) {
  if (typeof s !== 'string') return ''
  return s.charAt(0).toUpperCase() + s.slice(1)
}

// ==> START Generate ID
export function generateId(baseId = '', componentId, id) {
  if (baseId === '') {
    return null;
  }

  if (componentId.length === 0) {
    return `${baseId}-${id}`;
  }

  return `${baseId}-${componentId}-${id}`;
};
// ==> END Generate ID

export function CodePreview({ code, language, desc }) {
  useEffect(() => {
    Prism.highlightAll();
  }, []);
  /*---- List Language ----
  HTML          : markup
  JavaScript    : javascript
  CSS           : css
  CoffeeScript  : coffeescript
  PHP           : php
  Ruby          : ruby
  Go            : go */

  return (
    <div className="code-sections">
      <pre>
        <code className={`language-${language}`}>{code}</code>
      </pre>
    </div>
  );
};

export function sortAlfabetical(data, val) {
  if (!data) return data;


  const optionData = data.sort((a, b) => {
    // console.log('data bos', { a, b })
    switch (val) {
      case 'currency':
        return a.currency.localeCompare(b.currency);
      case 'currency-icon':
        return a.localeCompare(b);
      default:
        return a.text.localeCompare(b.text);
    }
  });

  // const Test = optionData.sort((a, b) => {
  //   return a.text.toLowerCase().indexOf("permata") - b.text.toLowerCase().indexOf("permata");
  // })

  // const result = data.filter(f => f.text.toLowerCase().startsWith('permata'))

  //   function sortInputFirst(input, data) {
  //     var first = [];
  //     var others = [];
  //     for (var i = 0; i < data.length; i++) {
  //         if (data[i].indexOf(input) == 0) {
  //             first.push(data[i]);
  //         } else {
  //             others.push(data[i]);
  //         }
  //     }
  //     first.sort();
  //     others.sort();
  //     return(first.concat(others));
  // }

  // var results = sortInputFirst('piz', data);

  const first = [];
  const second = [];
  const others = [];
  let arrSorted = [];
  const arrCurrency1 = [];
  const arrCurrency2 = [];
  const arrCurrencyRemaining = [];
  const arrNotSorted = [];
  let arrAll = ''
  switch (val) {
    case 'permata-priority':
      for (let i = 0; i < optionData.length; i++) {
        if (optionData[i].text.toLowerCase().indexOf('permata') === 0) {
          first.push(optionData[i]);
        } else if (
          (optionData[i].typeForm && optionData[i].typeForm === 'fedwire')
          || optionData[i].text.toLowerCase().indexOf('fedwire') > -1) {
          second.push(optionData[i]);
        } else {
          others.push(optionData[i]);
        }
      }
      first.sort();
      second.sort();
      others.sort();
      return first.concat(second).concat(others);
    case 'indonesia-country':
      for (let i = 0; i < optionData.length; i++) {
        if (optionData[i].text.toLowerCase() === 'indonesia') {
          first.push(optionData[i]);
        } else {
          second.push(optionData[i]);
        }
      }
      second.sort();
      return first.concat(second);
    case 'currency':
      arrSorted = JSON.parse(JSON.stringify(data));
      arrSorted.forEach((data, index) => {
        if (data.currency === 'IDR') {
          arrCurrency1.push(data);
        }
        else if (data.currency === 'USD') {
          arrCurrency2.push(data);
        }
        else {
          arrCurrencyRemaining.push(data);
        }
      });
      arrSorted.length = 0;
      // arrCurrency1.sort(function (a, b) {
      //   if (a.secondary < b.secondary) return -1;
      //   if (a.secondary > b.secondary) return 1;
      //   return 0;
      // });
      // arrCurrency2.sort(function (a, b) {
      //   if (a.secondary < b.secondary) return -1;
      //   if (a.secondary > b.secondary) return 1;
      //   return 0;
      // });
      // arrCurrencyRemaining.sort(function (a, b) {
      //   if (a.secondary < b.secondary) return -1;
      //   if (a.secondary > b.secondary) return 1;
      //   return 0;
      // });
      arrAll = arrNotSorted.concat(arrSorted, arrCurrency1, arrCurrency2, arrCurrencyRemaining);

      return arrAll;

    case 'currency-icon':
      arrSorted = JSON.parse(JSON.stringify(data));
      arrSorted.forEach((c) => {
        if (c === 'IDR') {
          arrCurrency1.push(c);
        }
        else if (c === 'USD') {
          arrCurrency2.push(c);
        }
        else {
          arrCurrencyRemaining.push(c);
        }
      });
      arrSorted.length = 0;
      arrAll = arrNotSorted.concat(arrSorted, arrCurrency1, arrCurrency2, arrCurrencyRemaining);

      return arrAll;

    case 'idr-number-priority':
      for (let i = 0; i < optionData.length; i++) {
        if (optionData[i].value === '+62') {
          first.push(optionData[i]);
        } else {
          others.push(optionData[i]);
        }
      }
      first.sort();
      second.sort();
      others.sort();
      return first.concat(second).concat(others);
    default:
      return optionData;
  }
}
export const capitalizeFirstLetter = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
export const ordinal = (i) => {
  const n = ["one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"];
  const s = ["zeroth", "first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth",
    "eleventh", "twelfth", "thirteenth", "fourteenth", "fifteenth", "sixteenth", "seventeenth", "eighteenth", "nineteenth"];
  const p = ["twent", "thirt", "fourt", "fift", "sixt", "sevent", "eight", "ninet"];
  const c = ["hundred", "thousand", "million", "billion", "trillion", "quadrillion", "quintillion"];
  const b = Math.floor(Math.log10(i));
  if (i < 20) return s[i]; // Special case for sub-20

  if (b === 1) { // Between 21 and 99
    if (i % 10 === 0) return `${p[Math.floor(i / 10) - 2]}ieth`; // On the tens, return p+"ieth"
    return `${p[Math.floor(i / 10) - 2]}y-${s[i % 10]}`; // Otherwise, return hyphenated
  }
  if (b === 2) { // Between 100 and 999
    const e = Math.floor(i / Math.pow(10, b)); // The first number
    return `${n[e - 1]}-${c[0]} ${ordinal(i - (e * Math.pow(10, b)))}`;
  }
  // Greater than 1000 we break into groups of 10^3 followed by a multiplier
  const m = b % 3 + 1; // Take the first m digits off
  const cm = Math.floor(b / 3);
  const x = Math.floor(i / Math.pow(10, b - m + 1));
  const numberToString = (y) => { // Converts a number less than 1000 to its string representation as a multiplier
    if (y < 20) return n[y - 1];
    if (y < 100) return `${p[Math.floor(y / 10) - 2]}y-${n[y % 10 - 1]}`;
    return `${n[Math.floor(y / 100) - 1]} ${c[0]} ${numberToString(y - (Math.floor(y / 100) * 100))}`;
  }
  return `${numberToString(x)} ${c[cm]} ${ordinal(i - (x * Math.pow(10, b - m + 1)))}`;
}

export const checkingEmailTagLength = (value) => {
  if (value.length > 0) {
    let lengthEmail = 0;
    value.forEach((item) => {
      lengthEmail += item.length
    });
    if (lengthEmail > 200) {
      value.pop();
      checkingEmailTagLength(value);
      return false;
    }
    return true;
  }
  return true;
};

export function numberWithCommas(x) {
  const nf = Intl.NumberFormat('en-US');
  if (x) return nf.format(x)

  return x;
}

export function parseNumberWithCommas(x) {
  return parseFloat(x.replace(/,/g, ''));
}

export const updateDataPaging = (detailData, perpage) => {
  const dataArray = [];
  detailData.forEach((data, index) => {
    const page = Math.ceil((index + 1) / perpage);
    data.page = page;
    dataArray.push(data);
  });
  return dataArray;
};

export const removeWANumberList = (data, index) => {
  const dataWhatsapp = [...data];
  dataWhatsapp.splice(index, 1);
  dataWhatsapp.forEach((data, index) => {
    if (data.valueWhatsapp === null) {
      data.valueWhatsapp = '';
    };
  });
  return dataWhatsapp;
};

export const gotoPage = (path) => {
  window.location.href = path;
}

export const getErrorMessageString = (errorCode, additionalText) => {
  let errorMessageObj;

  if (errorCode === '') {
    return '';
  }

  errorMessageObj = errorMessages.filter(function(e) {
    return e.errorCode === errorCode;
  });

  console.log(multiLanguage[errorMessageObj[0]])


  if (additionalText) {
    return `${multiLanguage[errorMessageObj[0].errorMessage] + additionalText}`;
  }
  return multiLanguage[errorMessageObj[0].errorMessage];
}

export const getDataByKeyword = (keyword = '', initialData = []) => {
  let newData = [...initialData];
  newData = initialData.filter(val => {
    if (val.text.toLowerCase().includes(keyword)) {
      return true;
    }

    if (val.accountName && val.accountName.toLowerCase().includes(keyword)) {
      return true;
    }

    return false;
  });
  return newData;
};


export const createListItems = ({
  loadingCallback = () => { },
  searchKeyword = '',
  kwLessMinimum = true,
  initialData = [],
  dataList = [],
  offset = 0,
  limit = 10,
  tempCallback = () => { },
  dataSetterCallback = () => { },
  offsetCallback = () => { }

}) => {
  loadingCallback(true);

  const sto = setTimeout(() => {
    let combine = [];
    // Cek terlebih dulu apakah keyword bank ada isinya atau tidak, // 2045
    // Jika tidak ada isinya maka jalankan fungsi dibawah ini
    if (searchKeyword === "" || kwLessMinimum) {
      // asumsi ambil data dari database sesuai page yang diinginkan
      const dataLimit = initialData.slice(offset,
        offset + limit
      );
      combine = dataList.concat(
        dataLimit
      );

      dataSetterCallback(combine);

      if (offset <= 0) tempCallback(combine);
    } else {
      // Namun jika keyword ada isinya, alias user sedang melakukan pencarian
      // Maka cari berdasarkan keywordnya juga
      const data = getDataByKeyword(searchKeyword, initialData);
      const dataLimit = data.slice(offset, offset + limit);
      combine = dataList.concat(dataLimit);
      dataSetterCallback(combine);
    }
    loadingCallback(false);
    // setiap kali ambil data maka tambahkan offset dengan limitTopupCategoryList agar bisa fetch halaman berikutnya
    if (combine.length > 0) offsetCallback(offset + limit);
    clearTimeout(sto);
  }, 1000);
};

export const sanitizeStringValue = (str = '') => {
  const hasUnsafeChar = str.includes('(') || str.includes(')');

  // replace unsafe with escaping char regex
  const keywordSafe = hasUnsafeChar ? str.replace(/(?=[() ])/g, '\\') : str;

  return keywordSafe;
}

export const findIndexKeyword = (data = {}, field = 'text', keyword = '') => {
  const keywordSafe = keyword.includes('(') || keyword.includes(')') ? keyword.replace(/(?=[() ])/g, '\\') : keyword;
  const startIndex = data[field].search(new RegExp(keywordSafe, "gi"));
  const endIndex = startIndex + keyword.length;
  const newKeyword = data[field].slice(startIndex, endIndex);

  const indexKeyword = data[field].indexOf(newKeyword);

  // console.log('findIndexKeyword', data, field, keyword, endIndex, startIndex, indexKeyword, newKeyword);

  return [indexKeyword, newKeyword];
}

export async function copyText(textToCopy) {
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(textToCopy);
  }

  // text area method
  const textArea = document.createElement("textarea");
  textArea.value = textToCopy;
  // make the textarea out of viewport
  textArea.style.position = "fixed";
  textArea.style.left = "-999999px";
  textArea.style.top = "-999999px";
  textArea.style.maxHeight = "0px";
  textArea.style.maxWidth = "0px";
  textArea.style.opacity = "0";
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  document.execCommand('copy');
  textArea.remove();
  return true;
}

export const isMobileDevice = () => /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

export const adjustmentStepperRecurring = (list) => {
  const newList = {
    stepList: []
  };
  const recurringTypeSection = {
    variant: 'inactive',
    number: 0,
    textInfo: 'RecurringType',
    anchorId: 'recurringType',
    confAnchorId: 'ConfirmationrecurringType',
    activated: false
  };
  if (
    newList.stepList.filter((item) => item.anchorId === 'recurringType')
      .length <= 0
  ) {
    newList.stepList.push(recurringTypeSection);
  }
  list.stepList.forEach((item) => {
    newList.stepList.push(item);
  });
  newList.stepList.forEach((item) => {
    if (item.anchorId === 'fromAccount') {
      item.textInfo = 'FromAccount';
    }
    if (item.anchorId === 'transactionDetails') {
      item.textInfo = 'TransactionDetails';
    }
  });
  newList.stepList.forEach((item) => {
    if (item.variant !== 'done' && item.variant !== 'current') {
      item.variant = 'done';
    }
  });
  if (
    newList.stepList.filter((item) => item.anchorId === 'recurringDetail')
      .length <= 0
  ) {
    newList.stepList.push({
      variant: 'done',
      number: 6,
      textInfo: 'Recurring',
      anchorId: 'recurringDetail',
      confAnchorId: 'Confirmationrecurring',
      activated: false
    });
  }

  return newList;
};

// set single query string value
export const setQueryParamValue = (queryString = '', key, value) => {
  const queryParams = new URLSearchParams(queryString)
  if (queryParams.has(key)) {
    queryParams.set(key, value);
  } else {
    queryParams.append(key, value);
  }
  return queryParams.toString();
}
