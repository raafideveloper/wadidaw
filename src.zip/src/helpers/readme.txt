==> ConfigLanguage.js
    File ini berfungsi untuk mengatur pengambilan nilai variabel yang ada di kamus kumpulan kata(dictionary.js),
    dimana didalam nya terdapat fungsi :
    -- language.MultiLanguageTitle
        untuk mendefinisan nilai dari bahasa dalam kamus,dimana variabelnya nantinya 
        menyamakan dengan variabel yang ada di kamus

    -- _getBahasa
        mengecek nilai bahasa yang ada di localStorage

    -- multiLanguage
        variabel yang du gunakan dalam component Global yang nantinya menentukan
        apakah mengambil bahasa ingris(en) atau indonesia(id)

==> dictionary.js
    kumpulan kamus multi bahasa yang di devinisikan didalamnya jika bahasa inggris
    itu (en) dan untuk indonesia (id)

***CARA PENGGUNAAN multiLanguage DALAM KOMPONEN***
1.  Daftarkan kata atau kaliman dalam file dictionary.js baik dalam bahasa indonesia
    maupun bahasa inggris,dalam pendaftarannya baik indonesia maupun inggris gunakan
    nama variabel yang sama
2.  Kemudian Daftarkan nama variabel yang ada dalam dictionary.js kedalam fungsi 
    language.MultiLanguageTitle dengan format :
    __namaVariabel__: lang.dictionary[bahasa].__namaVariabel__,
3.  Untuk menggunakannya gunakan multiLanguage.__namaVariabel__ pada component yang 
    diinginkan
    
Contoh:
    ingin merubah kalimat "kartu kredit" di component ForgotContent.js
    a. dictionary.js(dalam objek lang.dictionary):
        en:{
            CC:'Credit Card'
        },
        id:{
            CC:'Kartu Kredit'
        }

    b. ConfigLanguage.js(dalam fungsi language.MultiLanguageTitle):
        .....
            return {
                CC: lang.dictionary[bahasa].CC,
            }
        ....

    c. ForgotContent.js(di dalam component yang ingin di ganti):
        import multiLanguage from 'helpers';
        ......
            <div>
                ......
                ......
                    {multiLanguage.CC}
                ......
                ......
            </div>